
/* Program for timer0 on interrupt methed*/

#include "lpc17xx.h"
#include "timer_0_int.h"



int Timer_0_var ;

void TIMER0_IRQHandler (void) 
{
	 if((LPC_TIM0->IR & 0x01) == 0x01) 	// if MR0 interrupt
    {
        LPC_TIM0->IR |= 1 << 0; 	// Clear MR0 interrupt flag
		LPC_TIM0->TCR |= 1 << 1;
        Timer_0_var = 0x01;
    }
	return ;
}



void Start_timer_0(unsigned int delay) 
{
	Timer_0_var = 0x00 ;
	LPC_TIM0->MR0 = 1 << delay;
	LPC_TIM0->TCR |= 1 << 1;      // Reset Timer0
	LPC_TIM0->TCR &= ~(1 << 1);

	LPC_GPIO1->FIOSET   =  1<<29;	
	LPC_TIM0->TCR |= 1 << 0;      // Start timer

	 
	return ;

}

void stop_timer_0(void) 
{
	
	LPC_TIM0->TCR |= 1 << 1;
	Timer_0_var = 0x00 ;
//	LPC_TIM0->IR |= 1 << 0;
	
	LPC_GPIO1->FIOCLR   =  1<<29;
	return ;
}


void init_timer_0(void)
{
	 LPC_SC->PCONP |= 1 << 1;
	LPC_SC->PCLKSEL0 |= 1 << 2;	
	LPC_TIM0->MCR |= 1 << 0;      // Interrupt on Match0 compare

	LPC_TIM0->MCR |= 1 << 1;  

	NVIC_EnableIRQ(TIMER0_IRQn);	
    // Reset timer on Match 0.
		 	 
	return ;
}

