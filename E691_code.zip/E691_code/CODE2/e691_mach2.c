			#include "lpc17xx.h"
#include "hardware.h"
#include "type.h"
#include "utils.h"
#include "64x128GLCD.h"
#include "type.h"
#include "uart.h" 
#include "timer_0_int.h"
#include "key.h"  
#include "i2c.h"


#define keypad_delay 50000
#define PORT_USED		0


extern U8 data_table[];
/********************************************************************************************************************
 
INDEXING_FWD 		//08 -- 10	+ 01 = 11
INDEXING_RVS 		//08 -- 20	+ 01 = 21

ARM_FWD 			//08 -- 40	+ 02 = 42
ARM_RVS 			//08 -- 80	+ 02 = 82

HELMET1 			// 09 -- 01
HELMET2 			// 09 -- 02

NOZEL_FWD			//09 -- 04
NOZEL_RVS			//09 -- 08

PAINT_SOLONOID		// 09 -- 10
CYLINDER_SOLONOID 	// 09 -- 20

ELECTROMAGNET		// 09 -- 40
BUZZER				// 09 -- 80
COUNTER				// 0A -- 01


***********************************************************************************************************************/

#define INDEX_PROX1 		(1 << 21)  //P0
#define INDEX_PROX2	 		(1 << 22)  //P0

//#define INDEX_PROX2	 		(1 << 24)  //P0
#define ARM_LOWER_PROX1	 	(1 << 23)
//#define ARM_LOWER_PROX2	 	(1 << 24)

#define ARM_LOWER_PROX3	 	(1 << 25)

#define ARM_UPPER_PROX1 	(1 << 26)  //P0
#define ARM_UPPER_PROX2		(1 << 25)  //P1
//#define ARM_UPPER_PROX3		(1 << 26)  //P1	   

//#define NOZEL_INDEX	 		(1 << 26)	//P1
#define NOZEL_INDEX	 		(1 << 31)	//P1
#define NOZEL_HOME	 		(1 << 25)   //P3   

#define AUTO_BUTTON 		(1 << 26)	//P3
#define MANUAL_BUTTON 		(1 << 17)	//P1

#define START_BUTTON 		(1 << 16)	//P1

//INPUTS FOR MANUAL MODE
#define MANUAL_ARM_MOTOR		(1 << 15)	//P1
#define MANUAL_INDEX_MOTOR		(1 << 14)	//P1
#define MANUAL_HELMET_MOTOR1	(1 << 10)	//P1
#define MANUAL_HELMET_MOTOR2	(1 << 9)	//P1
#define MANUAL_NOZEL_MOTOR		(1 << 8)	//P1
#define MANUAL_FORWARD			(1 << 4)	//P1
#define MANUAL_REVERSE			(1 << 1)	//P1




unsigned int init_system(void);
void stop_process(void);
unsigned int System_status(void);
unsigned int System_process(void);


extern volatile uint8_t I2CMasterBuffer[I2C_PORT_NUM][BUFSIZE_i2c];
extern volatile uint8_t I2CSlaveBuffer[I2C_PORT_NUM][BUFSIZE_i2c];
extern volatile uint32_t I2CReadLength[I2C_PORT_NUM];
extern volatile uint32_t I2CWriteLength[I2C_PORT_NUM];


/**
********************************************************************************************
	Function Name :	is_valid_ascii()

	Description :
	
	Input :	Void

	Output : Void

	Note :
**********************************************************************************************
*/
U8 is_valid_ascii(S8 key)
{
  U8 retval = FALSE;
  
  if(key >= ' ' && key <= '~')	   
    retval = TRUE;

  return retval;
}

/**
********************************************************************************************
	Function Name :	lcd_display_char()

	Description :
	
	Input :	Void

	Output : Void

	Note :
**********************************************************************************************
*/
void lcd_display_char(U8 charecter)
{
  U8 width = 0, index = 0, data = 0;
  
  width = get_width_of_char(charecter);
  for(index = 0; index < width; index++)
  {
    data = get_data_from_data_table(charecter, index);
    LCD_WRITE_DATA(data);
  }
}

/**
********************************************************************************************
	Function Name :	lcd_display_string()

	Description :
	
	Input :	Void

	Output : Void

	Note :
**********************************************************************************************
*/
void lcd_display_string(U8 *str)
{
  if(str == NULL)
    return;
    
  while(*str != (U32)NULL)
  {
    lcd_display_char(*str);
    str++;
  }
}


void delay_ms( int val)		
{
	int i;
	int j;
	for(i = 0 ; i < val ; i++ )
	{
		for(j = 0 ; j < 10000 ; j++ ) ;
	}
	return ;
}

/**
*****************************************************************	
	Function Name :	main()

	Description :	To initialise system.

	Input :	none

	Output : int

	Note :
*****************************************************************
*/	
int main(void)
{
//	unsigned char key;
	
	SystemInit();
		I2C0Init();	
	HardwareInit();
	delay(100000);delay(100000);delay(100000);
	LCD_INIT();
	init_key();
	init_timer_0();
	
	//SAVE THE USER ID AND PASSWORD
	I2CWriteLength[PORT_USED] = 5;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = 0XA0;
	I2CMasterBuffer[PORT_USED][1] = 0x00;		/* address */
	I2CMasterBuffer[PORT_USED][2] = 0x00;		/* address */
	I2CMasterBuffer[PORT_USED][3] = 0x01;		/* Data0 */
	I2CMasterBuffer[PORT_USED][4] = 0x11;		/* Data0 */
		
	I2CEngine( PORT_USED );
	

	LCD_CLEAR(); 
		
	LCD_SET_PAGE(PAGE1 + 0 , COL1);
	lcd_display_string("WELCOME TO");
	LCD_SET_PAGE(PAGE1 + 2 , COL1);
	lcd_display_string("PAINTING ARM ");
	LCD_SET_PAGE(PAGE1 + 4, COL1);

	delay(100000);delay(100000);delay(100000);

	if(init_system() == 1)
	{  		
		stop_process();							
	}	
	else
	{
			LCD_CLEAR(); 
		
		LCD_SET_PAGE(PAGE1 + 0 , COL1);
		lcd_display_string("INITIALIZED");
		LCD_SET_PAGE(PAGE1 + 2 , COL1);
		lcd_display_string("START OPERATION");
		LCD_SET_PAGE(PAGE1 + 4, COL1);
		delay(100000);
		
		while(1)
		{
			if((!(LPC_GPIO3->FIOPIN & AUTO_BUTTON)))
			{
			
				while((LPC_GPIO1->FIOPIN & START_BUTTON)) ;
	
				while(1)
				{
					if((!(LPC_GPIO1->FIOPIN & MANUAL_BUTTON)))
					{
						 //stop_process();	
						 break;
					}
					else if((!(LPC_GPIO3->FIOPIN & AUTO_BUTTON)))
					{
						  if(System_process() == 1)
						  {
						   	stop_process();
							while(1); 						  	
						  }			   						
					}				   					
				}
			}
			else if((!(LPC_GPIO1->FIOPIN & MANUAL_BUTTON)))
			{
				while((LPC_GPIO1->FIOPIN & START_BUTTON)) ;
				if(System_process() == 1)
				{
				   	stop_process();
					while(1); 						  	
	            }				
			}
		}
	}  
    
}


 unsigned int init_system(void)
{
	unsigned int delay_time=0;
//	unsigned char t;


	//INITIALIZE THE INPUT PINS

	LPC_GPIO1->FIODIR &= ~(MANUAL_ARM_MOTOR|MANUAL_INDEX_MOTOR|MANUAL_HELMET_MOTOR1|MANUAL_HELMET_MOTOR2|MANUAL_NOZEL_MOTOR|MANUAL_FORWARD|MANUAL_REVERSE);
	LPC_GPIO0->FIODIR &= ~(INDEX_PROX1|INDEX_PROX2|ARM_LOWER_PROX1|ARM_LOWER_PROX3|ARM_UPPER_PROX1); //ARM_LOWER_PROX2
	LPC_GPIO1->FIODIR &= ~(ARM_UPPER_PROX2|NOZEL_INDEX|MANUAL_BUTTON|START_BUTTON);
	LPC_GPIO3->FIODIR &= ~(AUTO_BUTTON|NOZEL_HOME);

	/*INITIALIZING THE I2C EXPANDER IC PINS AS OUTPUTS*/
	 
	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x18;		/* address */
	I2CMasterBuffer[PORT_USED][2] = 0x00;		/* Data0 */
	
	I2CEngine( PORT_USED );	


	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x19;		/* address */
	I2CMasterBuffer[PORT_USED][2] = 0x00;		/* Data0 */
	
	I2CEngine( PORT_USED );	

	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x1A;		/* address */
	I2CMasterBuffer[PORT_USED][2] = 0x00;		/* Data0 */
	
	I2CEngine( PORT_USED );

	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x1B;		/* address */
	I2CMasterBuffer[PORT_USED][2] = 0x00;		/* Data0 */
	
	I2CEngine( PORT_USED );

	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x1C;		/* address */
	I2CMasterBuffer[PORT_USED][2] = 0x00;		/* Data0 */
	
	I2CEngine( PORT_USED );


	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
	I2CMasterBuffer[PORT_USED][2] = 0x00;		/* Data0 */
	
	I2CEngine( PORT_USED );	
	
	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
	I2CMasterBuffer[PORT_USED][2] = 0x00;		/* Data0 */
	
	I2CEngine( PORT_USED );	

	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x0A;		/* address */
	I2CMasterBuffer[PORT_USED][2] = 0x00;		/* Data0 */
	
	I2CEngine( PORT_USED );

	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x0B;		/* address */
	I2CMasterBuffer[PORT_USED][2] = 0x00;		/* Data0 */
	
	I2CEngine( PORT_USED );

	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x0C;		/* address */
	I2CMasterBuffer[PORT_USED][2] = 0x00;		/* Data0 */
	
	I2CEngine( PORT_USED );



	if((LPC_GPIO3->FIOPIN & NOZEL_HOME))
	{
		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x08;
		I2CEngine( PORT_USED );

		delay_ms(100);
		delay_time=0;

		while(1)
		{
			delay_time++;
			if(!(LPC_GPIO3->FIOPIN & NOZEL_HOME)) 
			{
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );
				break;
			}
			else if(delay_time>40000000)
			{
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );
				return 1; 
			}
		}
	}
	delay_ms(200);

	if((LPC_GPIO0->FIOPIN & ARM_LOWER_PROX1))
	{
		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x88;
		I2CEngine( PORT_USED );
		delay_ms(100);
		delay_time=0;

		while(1)
		{
			delay_time++;
			if(!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX1)) 
			{
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );
				break;
			}
			else if(delay_time>40000000)
			{
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );

				LCD_CLEAR(); 
				
				LCD_SET_PAGE(PAGE1 + 0 , COL1);
				lcd_display_string("ARM MOTOR ");
				LCD_SET_PAGE(PAGE1 + 2 , COL1);
				lcd_display_string("FAULT");
				LCD_SET_PAGE(PAGE1 + 4, COL1);
				delay(100);

				return 1; 
			}
		}
	}
	delay_ms(200);


	if((!(LPC_GPIO0->FIOPIN & INDEX_PROX1)) || (!(LPC_GPIO0->FIOPIN & INDEX_PROX2)))
	{
		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x00;
		I2CEngine( PORT_USED );
		
		delay_ms(50);
		//ELECTROMAGNET
		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x40;
		I2CEngine( PORT_USED );

		if((!(LPC_GPIO0->FIOPIN & INDEX_PROX1)))
		{
			I2CWriteLength[PORT_USED] = 4;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = 0XA0;
			I2CMasterBuffer[PORT_USED][1] = 0x00;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0x00;		/* Data0 */
			I2CMasterBuffer[PORT_USED][3] = 0x01;		/* Data1 */
			
			I2CEngine( PORT_USED );
		}
		else if((!(LPC_GPIO0->FIOPIN & INDEX_PROX2)))
		{
			I2CWriteLength[PORT_USED] = 4;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = 0XA0;
			I2CMasterBuffer[PORT_USED][1] = 0x00;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0x00;		/* Data0 */
			I2CMasterBuffer[PORT_USED][3] = 0x02;		/* Data1 */
			
			I2CEngine( PORT_USED );
		}  		
	}
	else
	{
//		I2CWriteLength[PORT_USED] = 3;
//		I2CReadLength[PORT_USED] = 0;
//		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
//		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
//		I2CMasterBuffer[PORT_USED][2] = 0x00;
//		I2CEngine( PORT_USED );
//
//		delay_ms(5000);
//
//		for ( i = 0; i < BUFSIZE_i2c; i++ )
//		{
//			I2CSlaveBuffer[PORT_USED][i] = 0x00;
//		}
//		I2CWriteLength[PORT_USED] = 3;
//		I2CReadLength[PORT_USED] = 0;
//		I2CMasterBuffer[PORT_USED][0] = 0XA0;
//		I2CMasterBuffer[PORT_USED][1] = 0x00;		/* address */
//		I2CMasterBuffer[PORT_USED][2] = 0x00;
//		I2CEngine( PORT_USED );
//		
//		for ( i = 0; i < BUFSIZE_i2c; i++ )
//		{
//			I2CSlaveBuffer[PORT_USED][i] = 0x00;
//		}
//	
//	
//		I2CWriteLength[PORT_USED] = 0;
//		I2CReadLength[PORT_USED] = 1;
//		/* address */
//		I2CMasterBuffer[PORT_USED][0] = 0XA1;
//		I2CEngine( PORT_USED );
//	
//		for(pos=0,t=0x00;t < I2CSlaveBuffer[0][0];t++,pos++);
//
//
//		if(pos == 1)
//		{
//			I2CWriteLength[PORT_USED] = 3;
//			I2CReadLength[PORT_USED] = 0;
//			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
//			I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
//			I2CMasterBuffer[PORT_USED][2] = 0x14;
//			I2CEngine( PORT_USED );
//
//			delay_ms(3000);
//			
//			I2CWriteLength[PORT_USED] = 3;
//			I2CReadLength[PORT_USED] = 0;
//			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
//			I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
//			I2CMasterBuffer[PORT_USED][2] = 0x11;
//			I2CEngine( PORT_USED );
//
//			delay_time=0;
//			while(1)
//			{
//				delay_time++;
//				if((!(LPC_GPIO0->FIOPIN & INDEX_PROX2)) )
//				{
//					//delay_ms(2000);
//					I2CWriteLength[PORT_USED] = 3;
//					I2CReadLength[PORT_USED] = 0;
//					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
//					I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
//					I2CMasterBuffer[PORT_USED][2] = 0x00;
//					I2CEngine( PORT_USED );
//
//					delay_ms(50);
//
//					I2CWriteLength[PORT_USED] = 4;
//					I2CReadLength[PORT_USED] = 0;
//					I2CMasterBuffer[PORT_USED][0] = 0XA0;
//					I2CMasterBuffer[PORT_USED][1] = 0x00;		/* address */
//					I2CMasterBuffer[PORT_USED][2] = 0x00;		/* Data0 */
//					I2CMasterBuffer[PORT_USED][3] = 0x02;		/* Data1 */
//					
//					I2CEngine( PORT_USED );
//					delay_ms(100);
//					break;
//				}
//				else if(delay_time > 40000000)
//				{
//					I2CWriteLength[PORT_USED] = 3;
//					I2CReadLength[PORT_USED] = 0;
//					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
//					I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
//					I2CMasterBuffer[PORT_USED][2] = 0x00;
//					I2CEngine( PORT_USED );
//					return 1; 
//				}
//			}
//		}
//		else if(pos == 2)
//		{ 			
//			I2CWriteLength[PORT_USED] = 3;
//			I2CReadLength[PORT_USED] = 0;
//			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
//			I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
//			I2CMasterBuffer[PORT_USED][2] = 0x24;
//			I2CEngine( PORT_USED );
//
//			delay_ms(3000);
//			
//			I2CWriteLength[PORT_USED] = 3;
//			I2CReadLength[PORT_USED] = 0;
//			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
//			I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
//			I2CMasterBuffer[PORT_USED][2] = 0x21;
//			I2CEngine( PORT_USED );
//
//			delay_time=0;
//			while(1)
//			{
//				delay_time++;
//				if((!(LPC_GPIO0->FIOPIN & INDEX_PROX1)) )
//				{
//					//delay_ms(2000);
//					I2CWriteLength[PORT_USED] = 3;
//					I2CReadLength[PORT_USED] = 0;
//					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
//					I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
//					I2CMasterBuffer[PORT_USED][2] = 0x00;
//					I2CEngine( PORT_USED );
//					
//					I2CWriteLength[PORT_USED] = 4;
//					I2CReadLength[PORT_USED] = 0;
//					I2CMasterBuffer[PORT_USED][0] = 0XA0;
//					I2CMasterBuffer[PORT_USED][1] = 0x00;		/* address */
//					I2CMasterBuffer[PORT_USED][2] = 0x00;		/* Data0 */
//					I2CMasterBuffer[PORT_USED][3] = 0x01;		/* Data1 */
//					
//					I2CEngine( PORT_USED );
//					delay_ms(100);
//					break;
//				}
//				else if(delay_time>40000000)
//				{
//					I2CWriteLength[PORT_USED] = 3;
//					I2CReadLength[PORT_USED] = 0;
//					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
//					I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
//					I2CMasterBuffer[PORT_USED][2] = 0x00;
//					I2CEngine( PORT_USED );
//					return 1; 
//				}
//			}	
//		}
//		else
//		{
//			I2CWriteLength[PORT_USED] = 3;
//			I2CReadLength[PORT_USED] = 0;
//			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
//			I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
//			I2CMasterBuffer[PORT_USED][2] = 0x24;
//			I2CEngine( PORT_USED );
//
//			delay_ms(3000);
			//delay_ms(250);
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0x21;
			I2CEngine( PORT_USED );

			delay_time=0;
			while(1)
			{
				delay_time++;
				if((!(LPC_GPIO0->FIOPIN & INDEX_PROX1)) )
				{
					//delay_ms(2000);
					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
					I2CMasterBuffer[PORT_USED][2] = 0x00;
					I2CEngine( PORT_USED );
					
					I2CWriteLength[PORT_USED] = 4;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = 0XA0;
					I2CMasterBuffer[PORT_USED][1] = 0x00;		/* address */
					I2CMasterBuffer[PORT_USED][2] = 0x00;		/* Data0 */
					I2CMasterBuffer[PORT_USED][3] = 0x01;		/* Data1 */
					
					I2CEngine( PORT_USED );
					delay_time=0;
					delay_ms(100);
					break;
				}
				else if(delay_time>60000000)
				{
					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
					I2CMasterBuffer[PORT_USED][2] = 0x00;
					I2CEngine( PORT_USED );

					LCD_CLEAR(); 
				
				LCD_SET_PAGE(PAGE1 + 0 , COL1);
				lcd_display_string("INDEX MOTOR ");
				LCD_SET_PAGE(PAGE1 + 2 , COL1);
				lcd_display_string("FAULT");
				LCD_SET_PAGE(PAGE1 + 4, COL1);
				delay(100);

					return 1; 
				}
			}
		//}
		//ELECTROMAGNET
		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x40;
		I2CEngine( PORT_USED );			
	}
	return 0;
}

void stop_process(void)
{
	
	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
	I2CMasterBuffer[PORT_USED][2] = 0x00;
	I2CEngine( PORT_USED );
	
	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
	I2CMasterBuffer[PORT_USED][2] = 0x80;
	I2CEngine( PORT_USED );
	
	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x0A;		/* address */
	I2CMasterBuffer[PORT_USED][2] = 0x00;
	I2CEngine( PORT_USED );

	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x0B;		/* address */
	I2CMasterBuffer[PORT_USED][2] = 0x00;
	I2CEngine( PORT_USED );

	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x0C;		/* address */
	I2CMasterBuffer[PORT_USED][2] = 0x00;
	I2CEngine( PORT_USED );

	return;
}


unsigned int System_status(void)
{
	if((LPC_GPIO0->FIOPIN & ARM_LOWER_PROX1)) 
	{
		return 1;
		
	}
	if((LPC_GPIO3->FIOPIN & NOZEL_HOME))
	{			
		return 1;
	}
	if(((LPC_GPIO0->FIOPIN & INDEX_PROX1)) && ((LPC_GPIO0->FIOPIN & INDEX_PROX2)))
	{			
		return 1; 		
	}

	return 0;

}

unsigned int System_process(void)
{
	unsigned int flag1,flag2,helmet1_flag;
	unsigned int delay_time;
	unsigned char port_value=0x00;
	
	
	helmet1_flag=0;

	
	if(System_status() == 1)
	{
		return 1;
	}

	//ELECTROMAGNET ON

	port_value|= 0x40;

	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
	I2CMasterBuffer[PORT_USED][2] = port_value;
	I2CEngine( PORT_USED );	

	delay_ms(250);

		if((!(LPC_GPIO0->FIOPIN & INDEX_PROX2)))
		{
			//HELMET1 ON
			port_value|= 0x02;
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
			I2CMasterBuffer[PORT_USED][2] = port_value;
			I2CEngine( PORT_USED );	
			helmet1_flag=1;
		}								  
		else if((!(LPC_GPIO0->FIOPIN & INDEX_PROX1)))
		{
			//HELMET2 ON
			port_value|= 0x01;
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
			I2CMasterBuffer[PORT_USED][2] = port_value;
			I2CEngine( PORT_USED );	

		}

	   	
		
		//ON THE PAINT 
		port_value|= 0x10;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value; 
		I2CEngine( PORT_USED );	
		delay_ms(1000);

		//TOTAL TIME TO GO UP WITH SPEED CONTROL IS APPROX 10 TO 12 SEC

		//ON THE ARM MOTOR WITH 320 RPM 

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x48;
		I2CEngine( PORT_USED );	
	//	LPC_GPIO1->FIOSET 	 =  ARM_ress3;
		//LPC_GPIO2->FIOSET 	 =  ARM_ress1;	
		

		//delay_ms(2000);
		flag1=0;
		flag2=0;
		delay_ms(250);

		//NOZEL MOTOR ON
		port_value|= 0x04;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );	

	//	delay_ms(500);	
	//	LPC_GPIO1->FIOSET 	 =  ARM_CYLINDER;

		//LPC_GPIO2->FIOCLR 	 =  ARM_ress1;
		delay_ms(2000);		 //3s

		//SLOW DOWN THE SPEED OF ARM MOTOR FOR MIDDLE PORTION OF HELMET
			
		//NOZEL MOTOR OFF
		port_value ^= 0x04;
		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );	

		delay_ms(2000);  //4sec changed on 14/1/17 for early nozel movement
	   		
	   //INCREASE THE SPEED OF ARM MOTOR FOR MIDDLE PORTION OF HELMET
	   	//LPC_GPIO1->FIOCLR 	 =  ARM_ress3;	

//		//NOZEL MOTOR ON
		port_value |= 0X04;
		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );	

		delay_ms(2000);	

		//ARM CYLINDER ON		
		port_value |= 0X20;
		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );	
		delay_time=0;

   		while(1)
		{
			delay_time++;
			
			if((!(LPC_GPIO0->FIOPIN & ARM_UPPER_PROX1)) && (flag1 == 0) )
			{
				delay_ms(100);
				if((!(LPC_GPIO0->FIOPIN & ARM_UPPER_PROX1)) && (flag1 == 0) )
				{
					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
					I2CMasterBuffer[PORT_USED][2] = 0x00;
					I2CEngine( PORT_USED );	
					flag1=1;
					delay_ms(100); 	
				}			
			}
			if((!(LPC_GPIO1->FIOPIN & NOZEL_INDEX)) && (flag2 == 0 ))
			{
				delay_ms(100);
				if((!(LPC_GPIO1->FIOPIN & NOZEL_INDEX)) && (flag2 == 0 ))
				{
					port_value ^= 0x04;

					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
					I2CMasterBuffer[PORT_USED][2] = port_value;
					I2CEngine( PORT_USED );		
					flag2=1;
					delay_ms(100);
				}				
			}
			if((flag1 == 1) && (flag2 == 1))
			{
			   	
				delay_ms(500);	   //10000
				//LPC_GPIO2->FIOCLR 	 = 	SOLONID_SIGNAL;
				break;
			}
			if(delay_time>40000000)	  //check the time
			{	
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	

				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );			 
				
				return 1;
			}
		}

		//TOTAL TIME TO GO DOWN IS  SEC
		//delay_ms(500);

		//ARM CYLINDER OFF

		port_value ^= 0X20;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );		
		delay_ms(200);

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x88;
		I2CEngine( PORT_USED );		

	   //delay_ms(250);
		delay_ms(200);  //2secs	 //changed so that the nozel follows the path

		//NOZEL MOTOR ON RVS
		port_value |= 0X08;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );		
	
		delay_ms(2000);
		
	
		flag1=0;
		flag2=0;
   		delay_time=0;

   		while(1)
		{
			delay_time++;
			if(delay_time>40000000)	  //check the time
			{			 
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );
						
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );		

				return 1;
			}
			if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX1)) && (flag1 == 0 ))
			{
				delay_ms(100);
				if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX1)) && (flag1 == 0 ))
				{
					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
					I2CMasterBuffer[PORT_USED][2] = 0x00;
					I2CEngine( PORT_USED );		
					
					//ELECTROMAGNET OFF
					port_value ^=0X40;

					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
					I2CMasterBuffer[PORT_USED][2] = port_value;
					I2CEngine( PORT_USED );		
					flag1=1;
					delay_ms(100);
				}
	
			}
			if((!(LPC_GPIO3->FIOPIN & NOZEL_HOME)) && (flag2 == 0 ))
			{
				delay_ms(100);	
				if((!(LPC_GPIO3->FIOPIN & NOZEL_HOME)) && (flag2 == 0 ))
				{
				   	//NOZEL MOTOR OFF
					port_value ^= 0X08;
					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
					I2CMasterBuffer[PORT_USED][2] = port_value;
					I2CEngine( PORT_USED );		
					flag2=1;
					delay_ms(100);
				}
			}		
			if((flag1 == 1) && (flag2 == 1))
			{
				
				
				delay_ms(500);
				break;
			}
		}

		//PAINT SOLONOID OFF
		port_value ^= 0X10;

		

		if(helmet1_flag == 1)
		{
		   port_value ^= 0X02;
		}
		else
		{
			port_value ^= 0X01;
		}

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );		

		delay_ms(500);

		if((!(LPC_GPIO0->FIOPIN & INDEX_PROX1)))
		{
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0x14;
			I2CEngine( PORT_USED );

			delay_ms(4000);
			
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0x11;
			I2CEngine( PORT_USED );
			delay_time=0;
			while(1)
			{
				delay_time++;
				
				if((!(LPC_GPIO0->FIOPIN & INDEX_PROX2)) )
				{
					delay_ms(100);
					if((!(LPC_GPIO0->FIOPIN & INDEX_PROX2)) )
					{
						//delay_ms(2000);
						I2CWriteLength[PORT_USED] = 3;
						I2CReadLength[PORT_USED] = 0;
						I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
						I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
						I2CMasterBuffer[PORT_USED][2] = 0x00;
						I2CEngine( PORT_USED );
						delay_time=0;
						//delay_ms(10);	 					
						
						break;
					}					
				}
				else if(delay_time>80000000)	  //check the time
				{			 
					return 1;
				}
			}
		}
		else if((!(LPC_GPIO0->FIOPIN & INDEX_PROX2)))
		{
			
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0x24;
			I2CEngine( PORT_USED );

			delay_ms(4000);
			
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0x21;
			I2CEngine( PORT_USED );

			delay_time=0;
			while(1)
			{
				delay_time++;
				
				if((!(LPC_GPIO0->FIOPIN & INDEX_PROX1)) )
				{
					delay_ms(100);
					if((!(LPC_GPIO0->FIOPIN & INDEX_PROX1)) )
					{
						//delay_ms(2000);
						I2CWriteLength[PORT_USED] = 3;
						I2CReadLength[PORT_USED] = 0;
						I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
						I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
						I2CMasterBuffer[PORT_USED][2] = 0x00;
						I2CEngine( PORT_USED );						
						//delay_ms(10);
						delay_time=0;						
									
						break;
					}
				}
				else if(delay_time>80000000)	  //check the time
				{			 
					return 1;
				}
			}	
		}
		
	port_value |= 0X40;
	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
	I2CMasterBuffer[PORT_USED][2] = port_value;
	I2CEngine( PORT_USED );	
	
	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x0A;		/* address */
	I2CMasterBuffer[PORT_USED][2] = 0X01;
	I2CEngine( PORT_USED );	
				 		
	delay_ms(100);

	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x0A;		/* address */
	I2CMasterBuffer[PORT_USED][2] = 0X00;
	I2CEngine( PORT_USED );	

	return 0;

}


