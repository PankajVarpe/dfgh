extern int Timer_0_var ;
extern void Start_timer_0(unsigned int delay);
extern void stop_timer_0(void) ;
extern void init_timer_0(void);
void TIMER0_IRQHandler (void); 

