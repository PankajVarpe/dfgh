#include "lpc17xx.h"                   

#include "key.h"
//#include "delay.h"
unsigned char keyboard[] = {'1','2','3','A','4','5','6','B','7','8','9','C','*','0','#','D'};
//unsigned char keyboard[] = {'1','4','7','*','2','5','8','0','3','6','9','#','A','B','C','D'};


#define LCD_KEY_DIR_0	   LPC_GPIO0->FIODIR
#define LCD_KEY_SET_0  		LPC_GPIO0->FIOSET
#define LCD_KEY_CLR_0    LPC_GPIO0->FIOCLR



//
#define ROW1 (1 << 0)
#define ROW2 (1 << 1)
#define ROW3 (1 << 4)
#define ROW4 (1 << 5)

#define COL1 (1 << 6)
#define COL2 (1 << 7)
#define COL3 (1 << 8)
#define COL4 (1 << 9)
//
//#define COL1 (1 << 5)
//#define COL2 (1 << 4)
//#define COL3 (1 << 1)
//#define COL4 (1 << 0)
//
//#define ROW1 (1 << 9)
//#define ROW2 (1 << 8)
//#define ROW3 (1 << 7)
//#define ROW4 (1 << 6)




#define delay_val 1000


#define KEY_OUTPUT	(COL1 |COL2 |COL3 | COL4);
#define KEY_INPUT	(ROW1 |ROW2 |ROW3 | ROW4);	
#define SET_ROW 	LCD_KEY_SET |= (ROW1 |ROW2 |ROW3 | ROW4);

void key_delay(unsigned long del)
{
	unsigned long i=0,j=0;
	for(i=0;i<del;i++)
		for(j=0;j<0xFF;j++)	 ;

}

void row_delay ()
{
	int i,j;
	for (i=0;i<0Xff;i++)
	{
		for (j=0;j<0Xff;j++)
		{
		}
	}

}
char goto_key(unsigned char i)
{
	
	if(!( LPC_GPIO0->FIOPIN & COL1))
	{
		//key_delay(delay_val);
		while(!(LPC_GPIO0->FIOPIN & COL1));
		
		
		 //lcd_putstring(0,"pressed key  ");
		return (keyboard[0+i]);
	}
	else if(!(LPC_GPIO0->FIOPIN & COL2))
	{
        //key_delay(delay_val);  
		while(!(LPC_GPIO0->FIOPIN & COL2));
		
		
		 //lcd_putstring(0,"pressed key  ");
		 return (keyboard[1+i]);
	}
	else if(!(LPC_GPIO0->FIOPIN & COL3))
	{
          
		//key_delay(delay_val);
		while(!(LPC_GPIO0->FIOPIN & COL3));
		
		//key_delay(delay_val);
		
		 //lcd_putstring(0,"pressed key  ");
		 return (keyboard[2+i]);
	}
	else if(!(LPC_GPIO0->FIOPIN & COL4))
	{
          
		while(!(LPC_GPIO0->FIOPIN & COL4));
		
		
		//return keyboard[3+i];
		 //lcd_putstring(0,"pressed key  ");
		 return (keyboard[3+i]);
	}
	else 
	{
		return 0;
	
	}
		
}
char read_key(void)
{
	char key = 0x00 ;
	//SET_ROW
	LCD_KEY_SET_0 |= (ROW1 |ROW2);
	LCD_KEY_SET_0 |= (ROW3 | ROW4);

	LCD_KEY_CLR_0	= ROW1;
	key_delay(delay_val);
	key = goto_key(0) ;
	if( key != 0)
	{
		return key ;
	}


	LCD_KEY_SET_0 |= (ROW1 |ROW2);
	LCD_KEY_SET_0 |= (ROW3 | ROW4);
	LCD_KEY_SET_0	= ROW1;
	key_delay(delay_val);
	LCD_KEY_CLR_0 = ROW2;
	key_delay(delay_val);
	key = goto_key(4);
	if( key != 0)
	{
		return key ;
	}

	
	LCD_KEY_SET_0 |= (ROW1 |ROW2);
	LCD_KEY_SET_0 |= (ROW3 | ROW4);
	LCD_KEY_SET_0 = ROW2;
	key_delay(delay_val);

	LCD_KEY_CLR_0	= ROW3;
	key_delay(delay_val);
	key = goto_key(8);
	if( key != 0)
	{
		return key ;
	}


		LCD_KEY_SET_0 |= (ROW1 |ROW2);
	LCD_KEY_SET_0 |= (ROW3 | ROW4);
	LCD_KEY_SET_0	= ROW3;
	key_delay(delay_val);
	LCD_KEY_CLR_0 = ROW4;
	key_delay(delay_val);
	key = goto_key(12);
	if( key != 0)
	{
		return key ;
	}
		LCD_KEY_SET_0 |= (ROW1 |ROW2);
	LCD_KEY_SET_0 |= (ROW3 | ROW4);
	LCD_KEY_SET_0 = ROW4;
	key_delay(delay_val); 	

	return 'n' ;
}	

 

char get_key(void)
{
	char key = 0x00 ;
	do
	{
		key = read_key();
	}
	while(key == 'n');
	
	return ( key ) ;
}


void init_key()
{
 	LCD_KEY_DIR_0 |= (ROW1 |ROW2|ROW3 | ROW4);
	
	LCD_KEY_DIR_0 &= ~(COL1 |COL2|COL3 | COL4);
		    //columns as output
	LCD_KEY_SET_0 |= (ROW1 |ROW2|ROW3 | ROW4);

}	





