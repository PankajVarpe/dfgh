extern void init_key(void);

extern char get_key(void);

//extern void delay1(int);

extern void key_pressed(unsigned char *key);

extern char goto_key(unsigned char i);
extern char read_key(void) ;
extern void row_delay(void);

