#include "lpc17xx.h"
#include "hardware.h"
#include "type.h"
#include "utils.h"
#include "64x128GLCD.h"
#include "type.h"
#include "uart.h" 
#include "timer_0_int.h"
#include "key.h"  
#include "i2c.h"


#define keypad_delay 50000
#define PORT_USED		0
#define disp_delay 500

unsigned char ASCII_num[]= { '0','1','2','3','4','5','6','7','8','9' };
extern U8 data_table[];
/********************************************************************************************************************
 
INDEXING_FWD 		//08 -- 10	+ 01 = 11
INDEXING_RVS 		//08 -- 20	+ 01 = 21

ARM_FWD 			//08 -- 40	+ 02 = 42
ARM_RVS 			//08 -- 80	+ 02 = 82

HELMET1 			// 09 -- 01
HELMET2 			// 09 -- 02

NOZEL_FWD			//09 -- 04
NOZEL_RVS			//09 -- 08

PAINT_SOLONOID		// 09 -- 10
CYLINDER_SOLONOID 	// 09 -- 20

ELECTROMAGNET		// 09 -- 40
BUZZER				// 09 -- 80
COUNTER				// 0A -- 01


***********************************************************************************************************************/

#define INDEX_PROX1 		(1 << 21)  //P0
#define INDEX_PROX2	 		(1 << 22)  //P0

//#define INDEX_PROX2	 		(1 << 24)  //P0
#define ARM_LOWER_PROX1	 	(1 << 23)
#define ARM_LOWER_PROX2	 	(1 << 24)

#define ARM_LOWER_PROX3	 	(1 << 25)

#define ARM_UPPER_PROX1 	(1 << 26)  //P0
#define ARM_UPPER_PROX2		(1 << 25)  //P1
//#define ARM_UPPER_PROX3		(1 << 26)  //P1	   

//#define NOZEL_INDEX	 		(1 << 26)	//P1
#define NOZEL_INDEX	 		(1U << 31)	//P1
#define NOZEL_HOME	 		(1 << 25)   //P3   

#define AUTO_BUTTON 		(1 << 26)	//P3
#define MANUAL_BUTTON 		(1 << 17)	//P1

#define START_BUTTON 		(1 << 16)	//P1

//INPUTS FOR MANUAL MODE
#define MANUAL_ARM_MOTOR		(1 << 15)	//P1
#define MANUAL_INDEX_MOTOR		(1 << 14)	//P1
#define MANUAL_HELMET_MOTOR1	(1 << 10)	//P1
#define MANUAL_HELMET_MOTOR2	(1 << 9)	//P1
#define MANUAL_NOZEL_MOTOR		(1 << 8)	//P1
#define MANUAL_FORWARD			(1 << 4)	//P1
#define MANUAL_REVERSE			(1 << 1)	//P1




unsigned int init_system(void);
void stop_process(void);
unsigned int System_status(void);
unsigned int System_process1(void);
unsigned int System_process2(void);
unsigned int System_process3(void);
unsigned int System_process4(void);
unsigned int System_process5(void);
unsigned int System_process6(void);
unsigned int System_process7(void);
unsigned int System_process8(void);
unsigned int System_RND(void);
unsigned int KIDS_OPEN(void);

extern volatile uint8_t I2CMasterBuffer[I2C_PORT_NUM][BUFSIZE_i2c];
extern volatile uint8_t I2CSlaveBuffer[I2C_PORT_NUM][BUFSIZE_i2c];
extern volatile uint32_t I2CReadLength[I2C_PORT_NUM];
extern volatile uint32_t I2CWriteLength[I2C_PORT_NUM];

unsigned char Read_key_Pad_var = 'x' ;
unsigned char Password[8] ;

void clear_sting(unsigned char *str )
{
	int i = 0 ;
     for( i = 0 ; str[i] != '\0' ; i++ )
     {
          str[i] = '\0' ;
     }
	 return ;
}

/**
********************************************************************************************
	Function Name :	is_valid_ascii()

	Description :
	
	Input :	Void

	Output : Void

	Note :
**********************************************************************************************
*/
U8 is_valid_ascii(S8 key)
{
  U8 retval = FALSE;
  
  if(key >= ' ' && key <= '~')	   
    retval = TRUE;

  return retval;
}

/**
********************************************************************************************
	Function Name :	lcd_display_char()

	Description :
	
	Input :	Void

	Output : Void

	Note :
**********************************************************************************************
*/
void lcd_display_char(U8 charecter)
{
  U8 width = 0, index = 0, data = 0;
  
  width = get_width_of_char(charecter);
  for(index = 0; index < width; index++)
  {
    data = get_data_from_data_table(charecter, index);
    LCD_WRITE_DATA(data);
  }
}

/**
********************************************************************************************
	Function Name :	lcd_display_string()

	Description :
	
	Input :	Void

	Output : Void

	Note :
**********************************************************************************************
*/
void lcd_display_string(U8 *str)
{
  if(str == NULL)
    return;
    
  while(*str != (U32)NULL)
  {
    lcd_display_char(*str);
    str++;
  }
}


void delay_ms( int val)		
{
	int i;
	int j;
	for(i = 0 ; i < val ; i++ )
	{
		for(j = 0 ; j < 10000 ; j++ ) ;
	}
	return ;
}

unsigned char Read_key_Pad(unsigned char *string, unsigned char op)
{
	unsigned char key = 'n' ;
	unsigned int j=0;
	unsigned long delay_time=0;
	j = 0 ;
	
	while( delay_time < 40000000)
	{
	
		delay_time++;
		key = read_key() ;
		if( key == 'n')//
			continue ;
		else if(op == 'c')
		{				
			delay_time=0;
			lcd_display_char(key);
			delay_ms(disp_delay) ;
			return key ;
		}
		/*else if( key == 'D' )
		{
			string[j] ='\0' ;
			stop_timer_0();
			return 'k';
		} */
		else if( key == 'A' )
		{
			string[j] ='\0' ;
			delay_time=0;
			return 'k';
		}
		else if( key != 'D')
		{
           if( op == 'n')
           {
                lcd_display_char(key);
                string[j++] = key ;
                continue ;
           }
           else
           {
		   		if(j>=4)
				{
					continue ;					
				}
				else
				{ 
                    lcd_display_char('*');
                    string[j++] = key ;
				}
                
           }
		}
	}
	//stop_timer_0();
	return 'x';	
}

/**
*****************************************************************	
	Function Name :	main()

	Description :	To initialise system.

	Input :	none

	Output : int

	Note :
*****************************************************************
*/	
int main(void)
{
	//unsigned char prog_status;
	unsigned int manual_flag;
	unsigned short int prog_status=0;

	SystemInit();
	I2C0Init();	
	HardwareInit();
	delay(100000);delay(100000);delay(100000);
	LCD_INIT();
	init_key();
	init_timer_0();
	

	LCD_CLEAR(); 
		
	LCD_SET_PAGE(PAGE1 + 0 , COL1);
	lcd_display_string("WELCOME TO");
	LCD_SET_PAGE(PAGE1 + 2 , COL1);
	lcd_display_string("PAINTING ARM ");
	LCD_SET_PAGE(PAGE1 + 4, COL1);

	delay(100000);delay(100000);delay(100000);

	if(init_system() == 1)
	{  		
		stop_process();							
	}	
	else
	{
		prog_status= 0 ;
		LCD_CLEAR(); 
		LCD_SET_PAGE(PAGE1 + 0 , COL1);
		lcd_display_string("INITIALIZED");
		LCD_SET_PAGE(PAGE1 + 2 , COL1);
		lcd_display_string("START OPERATION");
		LCD_SET_PAGE(PAGE1 + 4, COL1);

		LCD_CLEAR();
				
		while(prog_status == 0)
		{			
			
			LCD_SET_PAGE(PAGE1 + 1 , COL1);
			lcd_display_string("SET HELMET TYPE ");
			delay_ms(disp_delay);
	
			LCD_CLEAR();
			LCD_SET_PAGE(PAGE1 + 1 , COL1);
			lcd_display_string("1.  RALLY ");	
			
			LCD_SET_PAGE(PAGE1 + 2 , COL1);
			lcd_display_string("2.  VERVE/CRUISER/");
			
			LCD_SET_PAGE(PAGE1 + 3 , COL1);
			lcd_display_string("     BOOLEAN/CRUX");	
			
			LCD_SET_PAGE(PAGE1 + 4 , COL1);
			lcd_display_string("3.  BUD HELMET");
			
			LCD_SET_PAGE(PAGE1 + 5 , COL1);
			lcd_display_string("4.  FULL FACE");

			LCD_SET_PAGE(PAGE1 + 6 , COL1);
			lcd_display_string("5.  KIDS OPEN FACE");

			
			
			LCD_SET_PAGE(PAGE1 + 7 , COL1);
			Read_key_Pad_var = Read_key_Pad(Password, 'c') ;
			
			clear_sting( Password );
			
			
			switch ( Read_key_Pad_var )
			{ 
				case '1':
				{
					prog_status=1 ;	
//					LCD_CLEAR();
//					LCD_SET_PAGE(PAGE1 + 1 , COL1);
//					lcd_display_string("HELMET : RALLY ");	
					
					prog_status=99;

					while(prog_status == 99)
					{			
						LCD_CLEAR();
						LCD_SET_PAGE(PAGE1 + 1, COL1);
						lcd_display_string("SET COLOUR ");
						delay_ms(disp_delay);
				
						//LCD_CLEAR();
						LCD_SET_PAGE(PAGE1 + 3 , COL1);
						lcd_display_string("1. BLACK ");	
						
						LCD_SET_PAGE(PAGE1 + 4 , COL1);
						lcd_display_string("2. METALLIC BLUE");	

						LCD_SET_PAGE(PAGE1 + 5 , COL1);
						lcd_display_string("3. MAIN SCREEN");	
						
						
						LCD_SET_PAGE(PAGE1 + 6 , COL1);
						Read_key_Pad_var = Read_key_Pad(Password, 'c') ;
						
						clear_sting( Password );
						
						
						switch ( Read_key_Pad_var )
						{ 
							case '1':
							{
								prog_status=1 ;	
								LCD_CLEAR();
								LCD_SET_PAGE(PAGE1 + 1 , COL1);
								lcd_display_string("HELMET TYPE ");	
								LCD_SET_PAGE(PAGE1 + 2 , COL1);
								lcd_display_string(" RALLY BLACK");						
								break;
							}
							case '2':
							{
								prog_status=6 ;	
								LCD_CLEAR();
								LCD_SET_PAGE(PAGE1 + 1 , COL1);
								lcd_display_string("HELMET TYPE ");	
								LCD_SET_PAGE(PAGE1 + 2 , COL1);
								lcd_display_string("   RALLY BLUE");						
								break;
							}
							case '3':
							{
								prog_status= 0;	
													
								break;
							}		
							default :
							{
								prog_status=99 ;	
								break;
							}
						}
					}						
					break;
				}
				case '2':
				{
					prog_status= 2 ;
					LCD_CLEAR();
					LCD_SET_PAGE(PAGE1 + 1 , COL1);
					lcd_display_string("HELMET TYPE ");	
					LCD_SET_PAGE(PAGE1 + 2 , COL1);
					lcd_display_string(" VERVE / CRUISER /");	
					LCD_SET_PAGE(PAGE1 + 3 , COL1);
					lcd_display_string("  BOOLEAN / CRUX ");		
					break;
				}	
				case '3':
				{
					//prog_status= 4 ;
					LCD_CLEAR();
					LCD_SET_PAGE(PAGE1 + 1 , COL1);
					lcd_display_string("HELMET TYPE ");	

					LCD_SET_PAGE(PAGE1 + 2 , COL1);
					lcd_display_string("  BUDS HELMET");					
					
					
					prog_status=99;

					while(prog_status == 99)
					{			
						
						LCD_CLEAR();
						LCD_SET_PAGE(PAGE1 + 1, COL1);
						lcd_display_string("SET TYPE ");
						delay_ms(disp_delay);
				
						
						LCD_SET_PAGE(PAGE1 + 3 , COL1);
						lcd_display_string("1. BUDS OPEN FACE");	
						
						LCD_SET_PAGE(PAGE1 + 4 , COL1);
						lcd_display_string("2. BUDS FULL FACE");	

						LCD_SET_PAGE(PAGE1 + 5 , COL1);
						lcd_display_string("3. MAIN SCREEN");	
						
						
						LCD_SET_PAGE(PAGE1 + 6 , COL1);
						Read_key_Pad_var = Read_key_Pad(Password, 'c') ;
						
						clear_sting( Password );
						
						
						switch ( Read_key_Pad_var )
						{ 
							case '1':
							{
								prog_status= 7 ;
								LCD_CLEAR();
								LCD_SET_PAGE(PAGE1 + 1 , COL1);
								lcd_display_string("HELMET TYPE ");	
			
								LCD_SET_PAGE(PAGE1 + 2 , COL1);
								lcd_display_string(" BUDS OPEN FACE");
																	
								break;
							}
							case '2':
							{
								prog_status= 4 ;
								LCD_CLEAR();
								LCD_SET_PAGE(PAGE1 + 1 , COL1);
								lcd_display_string("HELMET TYPE ");	
			
								LCD_SET_PAGE(PAGE1 + 2 , COL1);
								lcd_display_string(" BUDS FULL FACE");
								
							
								break;
							}
							case '3':
							{
								prog_status= 0;
							
							
								break;
							}				
							default :
							{
								prog_status=99 ;	
								break;
							}
						}
					}	
					break;
				}  
				case '4':
				{
					//prog_status= 5 ;
					LCD_CLEAR();
					LCD_SET_PAGE(PAGE1 + 1 , COL1);
					lcd_display_string("HELMET : FULL FACE");	

					//LCD_SET_PAGE(PAGE1 + 2 , COL1);
					//lcd_display_string("ADJUST INDEXING ARM");	
					
					prog_status=99;

					while(prog_status == 99)
					{			
						
						LCD_CLEAR();
						LCD_SET_PAGE(PAGE1 + 1, COL1);
						lcd_display_string("SET TYPE ");
						delay_ms(disp_delay);
				
						LCD_CLEAR();
						LCD_SET_PAGE(PAGE1 + 1 , COL1);
						lcd_display_string("1. AXOR/GLISS/SHIRO/");
						LCD_SET_PAGE(PAGE1 + 2 , COL1);
						lcd_display_string("    A3");	
						
						LCD_SET_PAGE(PAGE1 + 3 , COL1);
						lcd_display_string("2. OFF ROAD");
						
						LCD_SET_PAGE(PAGE1 + 4 , COL1);
						lcd_display_string("3. ULTIMO / A4");
						
						LCD_SET_PAGE(PAGE1 + 5 , COL1);
						lcd_display_string("4. BELL");	

						LCD_SET_PAGE(PAGE1 + 6 , COL1);
						lcd_display_string("5. MAIN SCREEN");
						
						
						LCD_SET_PAGE(PAGE1 + 7 , COL1);
						Read_key_Pad_var = Read_key_Pad(Password, 'c') ;
						
						clear_sting( Password );
						
						
						switch ( Read_key_Pad_var )
						{ 
							case '1':
							{
								prog_status= 5 ;
								LCD_CLEAR();
								LCD_SET_PAGE(PAGE1 + 1 , COL1);
								lcd_display_string("HELMET TYPE ");	
			
								LCD_SET_PAGE(PAGE1 + 2 , COL1);
								lcd_display_string("AXOR/GLISS/SHIRO/A3");
								
								LCD_SET_PAGE(PAGE1 + 4 , COL1);
								lcd_display_string("ADJUST INDEXING ARM");	
								break;
							}
							case '2':
							{
								prog_status= 3 ;
								LCD_CLEAR();
								LCD_SET_PAGE(PAGE1 + 1 , COL1);
								lcd_display_string("HELMET TYPE ");	
			
								LCD_SET_PAGE(PAGE1 + 2 , COL1);
								lcd_display_string(" OFF ROAD FULL FACE");
								
								LCD_SET_PAGE(PAGE1 + 4 , COL1);
								lcd_display_string("ADJUST INDEXING ARM");	
								break;
							}
							case '3':
							{
								prog_status= 8 ;
								LCD_CLEAR();
								LCD_SET_PAGE(PAGE1 + 1 , COL1);
								lcd_display_string("HELMET TYPE ");	
			
								LCD_SET_PAGE(PAGE1 + 2 , COL1);
								lcd_display_string("ULTIMO/A4 FULL FACE");
								
								LCD_SET_PAGE(PAGE1 + 4 , COL1);
								lcd_display_string("ADJUST INDEXING ARM");	
								break;
							}
							case '4':
							{
								prog_status= 1 ;
								LCD_CLEAR();
								LCD_SET_PAGE(PAGE1 + 1 , COL1);
								lcd_display_string("HELMET TYPE ");	
			
								LCD_SET_PAGE(PAGE1 + 2 , COL1);
								lcd_display_string(" BELL  FULL FACE");
								
								LCD_SET_PAGE(PAGE1 + 4 , COL1);
								lcd_display_string("ADJUST INDEXING ARM");	
								break;
							}		
							case '5':
							{
								prog_status= 0 ;
									
								break;
							}			
							default :
							{
								prog_status=99 ;	
								break;
							}
						}
					}		
					break;
				}
				case '5':
				{
					prog_status= 9 ;
					LCD_CLEAR();
					LCD_SET_PAGE(PAGE1 + 1 , COL1);
					lcd_display_string("HELMET TYPE ");	
					LCD_SET_PAGE(PAGE1 + 2 , COL1);
					lcd_display_string(" KIDS OPEN FACE");	
							
					break;
				}
				default :
				{
					prog_status=0 ;	
					break;
				}
			}
		}

		manual_flag=0;
		while(1)
		{
			
			if(((LPC_GPIO3->FIOPIN & AUTO_BUTTON)) && ((LPC_GPIO1->FIOPIN & MANUAL_BUTTON)) )
			{
			
				manual_flag=1;
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0X00;
				I2CEngine( PORT_USED );	
				delay_ms(100);	
				
				while(manual_flag)
				{
					
					
					if((!(LPC_GPIO3->FIOPIN & AUTO_BUTTON)) || (!(LPC_GPIO1->FIOPIN & MANUAL_BUTTON)) )
					{
						manual_flag=0;
						I2CWriteLength[PORT_USED] = 3;
						I2CReadLength[PORT_USED] = 0;
						I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
						I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
						I2CMasterBuffer[PORT_USED][2] = 0X40;
						I2CEngine( PORT_USED );		
						delay_ms(100);

						break;
					}
					if(!(LPC_GPIO1->FIOPIN & MANUAL_ARM_MOTOR))
					{
						
						while(1)
						{
							if((!(LPC_GPIO3->FIOPIN & AUTO_BUTTON)) || (!(LPC_GPIO1->FIOPIN & MANUAL_BUTTON)) )
							{
								manual_flag=0;
								break;
							}
							if((LPC_GPIO1->FIOPIN & MANUAL_ARM_MOTOR))
							{
								break;
							}
							if(!(LPC_GPIO1->FIOPIN & MANUAL_FORWARD))
							{
																
								if((LPC_GPIO0->FIOPIN & ARM_UPPER_PROX1))
								{
									I2CWriteLength[PORT_USED] = 3;
									I2CReadLength[PORT_USED] = 0;
									I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
									I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
									I2CMasterBuffer[PORT_USED][2] = 0x48;
									I2CEngine( PORT_USED );
									delay_ms(100);
								}
								else if(!(LPC_GPIO0->FIOPIN & ARM_UPPER_PROX1))
								{
								 	I2CWriteLength[PORT_USED] = 3;
									I2CReadLength[PORT_USED] = 0;
									I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
									I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
									I2CMasterBuffer[PORT_USED][2] = 0x00;
									I2CEngine( PORT_USED );
									delay_ms(100);
								}  								
							}
							else if(!(LPC_GPIO1->FIOPIN & MANUAL_REVERSE))
							{
								if((LPC_GPIO0->FIOPIN & ARM_LOWER_PROX1))
								{
									I2CWriteLength[PORT_USED] = 3;
									I2CReadLength[PORT_USED] = 0;
									I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
									I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
									I2CMasterBuffer[PORT_USED][2] = 0x88;
									I2CEngine( PORT_USED );
									delay_ms(100);
								}
								else if(!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX1))
								{
								 	I2CWriteLength[PORT_USED] = 3;
									I2CReadLength[PORT_USED] = 0;
									I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
									I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
									I2CMasterBuffer[PORT_USED][2] = 0x00;
									I2CEngine( PORT_USED );
									delay_ms(100);
								}  			
							}
							else 
							{
							 	I2CWriteLength[PORT_USED] = 3;
								I2CReadLength[PORT_USED] = 0;
								I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
								I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
								I2CMasterBuffer[PORT_USED][2] = 0x00;
								I2CEngine( PORT_USED );
								delay_ms(100);
							}  	
						}		
					}
					else if(!(LPC_GPIO1->FIOPIN & MANUAL_NOZEL_MOTOR))
					{						
						while(1)
						{
							if((!(LPC_GPIO3->FIOPIN & AUTO_BUTTON)) || (!(LPC_GPIO1->FIOPIN & MANUAL_BUTTON)) )
							{
								manual_flag=0;
								break;
							}
							if((LPC_GPIO1->FIOPIN & MANUAL_NOZEL_MOTOR))
							{
								break;
							}
							if(!(LPC_GPIO1->FIOPIN & MANUAL_FORWARD))
							{
																
								if((!(LPC_GPIO1->FIOPIN & NOZEL_INDEX)) && (!(LPC_GPIO3->FIOPIN & NOZEL_HOME)))
								{
									I2CWriteLength[PORT_USED] = 3;
									I2CReadLength[PORT_USED] = 0;
									I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
									I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
									I2CMasterBuffer[PORT_USED][2] = 0x04;
									I2CEngine( PORT_USED );
									delay_ms(100);
								}
								else if(((LPC_GPIO1->FIOPIN & NOZEL_INDEX)) && ((LPC_GPIO3->FIOPIN & NOZEL_HOME)))
								{
									I2CWriteLength[PORT_USED] = 3;
									I2CReadLength[PORT_USED] = 0;
									I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
									I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
									I2CMasterBuffer[PORT_USED][2] = 0x04;
									I2CEngine( PORT_USED );
									delay_ms(100);
								}
								else if(!(LPC_GPIO1->FIOPIN & NOZEL_INDEX))
								{
								 	I2CWriteLength[PORT_USED] = 3;
									I2CReadLength[PORT_USED] = 0;
									I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
									I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
									I2CMasterBuffer[PORT_USED][2] = 0x00;
									I2CEngine( PORT_USED );
									delay_ms(100);
								}  								
							}
							else if(!(LPC_GPIO1->FIOPIN & MANUAL_REVERSE))
							{
								if((!(LPC_GPIO1->FIOPIN & NOZEL_INDEX)) && (!(LPC_GPIO3->FIOPIN & NOZEL_HOME)))
								{
									I2CWriteLength[PORT_USED] = 3;
									I2CReadLength[PORT_USED] = 0;
									I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
									I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
									I2CMasterBuffer[PORT_USED][2] = 0x00;
									I2CEngine( PORT_USED );
									delay_ms(100);
								}
								else 
								{
								 	I2CWriteLength[PORT_USED] = 3;
									I2CReadLength[PORT_USED] = 0;
									I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
									I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
									I2CMasterBuffer[PORT_USED][2] = 0x08;
									I2CEngine( PORT_USED );
									delay_ms(100);
								}  			
							}
							else 
							{
							 	I2CWriteLength[PORT_USED] = 3;
								I2CReadLength[PORT_USED] = 0;
								I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
								I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
								I2CMasterBuffer[PORT_USED][2] = 0x00;
								I2CEngine( PORT_USED );
								delay_ms(100);
							}  	
						}		
					}
					else if(!(LPC_GPIO1->FIOPIN & MANUAL_HELMET_MOTOR1))
					{
						while(1)
						{
							if((!(LPC_GPIO3->FIOPIN & AUTO_BUTTON)) || (!(LPC_GPIO1->FIOPIN & MANUAL_BUTTON)) )
							{
								manual_flag=0;
								break;
							}
							if((LPC_GPIO1->FIOPIN & MANUAL_HELMET_MOTOR1))
							{
								break;
							}
							if(!(LPC_GPIO1->FIOPIN & MANUAL_FORWARD))
							{
																
								I2CWriteLength[PORT_USED] = 3;
								I2CReadLength[PORT_USED] = 0;
								I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
								I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
								I2CMasterBuffer[PORT_USED][2] = 0x01;
								I2CEngine( PORT_USED );
								delay_ms(100);
							  								
							}
							else 
							{
								I2CWriteLength[PORT_USED] = 3;
								I2CReadLength[PORT_USED] = 0;
								I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
								I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
								I2CMasterBuffer[PORT_USED][2] = 0x00;
								I2CEngine( PORT_USED );	
								delay_ms(100);		
							}
						}		
					}
					else if(!(LPC_GPIO1->FIOPIN & MANUAL_HELMET_MOTOR2))
					{
						while(1)
						{
							if((!(LPC_GPIO3->FIOPIN & AUTO_BUTTON)) || (!(LPC_GPIO1->FIOPIN & MANUAL_BUTTON)) )
							{
								manual_flag=0;
								break;
							}
							if((LPC_GPIO1->FIOPIN & MANUAL_HELMET_MOTOR2))
							{
								break;
							}
							if(!(LPC_GPIO1->FIOPIN & MANUAL_FORWARD))
							{																
								I2CWriteLength[PORT_USED] = 3;
								I2CReadLength[PORT_USED] = 0;
								I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
								I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
								I2CMasterBuffer[PORT_USED][2] = 0x02;
								I2CEngine( PORT_USED );	
								delay_ms(100);						  								
							}
							else 
							{
								I2CWriteLength[PORT_USED] = 3;
								I2CReadLength[PORT_USED] = 0;
								I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
								I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
								I2CMasterBuffer[PORT_USED][2] = 0x00;
								I2CEngine( PORT_USED );	
								delay_ms(100);		
							}
						}		
					}
					else if(!(LPC_GPIO1->FIOPIN & MANUAL_INDEX_MOTOR))
					{
						while(1)
						{
							if((!(LPC_GPIO3->FIOPIN & AUTO_BUTTON)) || (!(LPC_GPIO1->FIOPIN & MANUAL_BUTTON)) )
							{
								manual_flag=0;
								break;
							}
							if((LPC_GPIO1->FIOPIN & MANUAL_INDEX_MOTOR))
							{
								break;
							}
							if(!(LPC_GPIO1->FIOPIN & MANUAL_FORWARD))
							{
																
								if(((LPC_GPIO0->FIOPIN & INDEX_PROX2)))
								{
																	
									I2CWriteLength[PORT_USED] = 3;
									I2CReadLength[PORT_USED] = 0;
									I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
									I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
									I2CMasterBuffer[PORT_USED][2] = 0x11;
									I2CEngine( PORT_USED );
									delay_ms(100);
								}
								else if(!(LPC_GPIO0->FIOPIN & INDEX_PROX2))
								{
								 	I2CWriteLength[PORT_USED] = 3;
									I2CReadLength[PORT_USED] = 0;
									I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
									I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
									I2CMasterBuffer[PORT_USED][2] = 0x00;
									I2CEngine( PORT_USED );
									delay_ms(100);
								}  								
							}
							else if(!(LPC_GPIO1->FIOPIN & MANUAL_REVERSE))
							{
								if(((LPC_GPIO0->FIOPIN & INDEX_PROX1)))
								{
																	
									I2CWriteLength[PORT_USED] = 3;
									I2CReadLength[PORT_USED] = 0;
									I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
									I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
									I2CMasterBuffer[PORT_USED][2] = 0x21;
									I2CEngine( PORT_USED );
									delay_ms(100);
								}
								else if(!(LPC_GPIO0->FIOPIN & INDEX_PROX1))
								{
								 	I2CWriteLength[PORT_USED] = 3;
									I2CReadLength[PORT_USED] = 0;
									I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
									I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
									I2CMasterBuffer[PORT_USED][2] = 0x00;
									I2CEngine( PORT_USED );
									delay_ms(100);
								}  			  			
							}
							else 
							{
							 	I2CWriteLength[PORT_USED] = 3;
								I2CReadLength[PORT_USED] = 0;
								I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
								I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
								I2CMasterBuffer[PORT_USED][2] = 0x00;
								I2CEngine( PORT_USED );
								delay_ms(100);
							}  			
						}		
					}					
				}
			}
			else if((!(LPC_GPIO3->FIOPIN & AUTO_BUTTON)) || (!(LPC_GPIO1->FIOPIN & MANUAL_BUTTON)) )
			{
				if((!(LPC_GPIO3->FIOPIN & AUTO_BUTTON)))
				{
					if(!(LPC_GPIO1->FIOPIN & START_BUTTON)) 
					{
						delay_ms(250);
						if(!(LPC_GPIO1->FIOPIN & START_BUTTON)) 
						{
							while(1)
							{
								if((!(LPC_GPIO3->FIOPIN & AUTO_BUTTON)))
								{
									  switch (prog_status)
									  {
									  	case 1:
										{
											if(System_process1() == 1)
											{
												stop_process();
												while(1); 						  	
											}
											break;	
										}
										case 2:
										{
											if(System_process2() == 1)
											{
												stop_process();
												while(1); 						  	
											}
											break;	
										}
										case 3:
										{
											if(System_process3() == 1)
											{
												stop_process();
												while(1); 						  	
											}
											break;	
										}
										case 4:
										{
											if(System_process4() == 1)
											{
												stop_process();
												while(1); 						  	
											}
											break;	
										}
										case 5:
										{
											if(System_process5() == 1)
											{
												stop_process();
												while(1); 						  	
											}
											break;	
										}
//										case 6:
//										{
//											if(System_process6() == 1)
//											{
//												stop_process();
//												while(1); 						  	
//											}
//											break;	
//										}
										case 7:
										{
											if(System_process7() == 1)
											{
												stop_process();
												while(1); 						  	
											}
											break;	
										}
										case 8:
										{
											if(System_RND() == 1)
											{
												stop_process();
												while(1); 						  	
											}
											break;	
										}
										case 9:
										{
											if(KIDS_OPEN() == 1)
											{
												stop_process();
												while(1); 						  	
											}
											break;	
										}
									  }							  		   						
								}
								else
								{
									break;
								}				   					
							}
						}
					}					
				}
				else if((!(LPC_GPIO1->FIOPIN & MANUAL_BUTTON)))
				{
					if(!(LPC_GPIO1->FIOPIN & START_BUTTON)) 
					{
						delay_ms(250);
						if(!(LPC_GPIO1->FIOPIN & START_BUTTON)) 
						{

							switch (prog_status)
							{
							  	case 1:
								{
									if(System_process1() == 1)
									{
										stop_process();
										while(1); 						  	
									}
									break;	
								}
								case 2:
								{
									if(System_process2() == 1)
									{
										stop_process();
										while(1); 						  	
									}
									break;	
								}
								case 3:
								{
									if(System_process3() == 1)
									{
										stop_process();
										while(1); 						  	
									}
									break;	
								}
								case 4:
								{
									if(System_process4() == 1)
									{
										stop_process();
										while(1); 						  	
									}
									break;	
								}
								case 5:
								{
									if(System_process5() == 1)
									{
										stop_process();
										while(1); 						  	
									}
									break;	
								}
//								case 6:
//								{
//									if(System_process6() == 1)
//									{
//										stop_process();
//										while(1); 						  	
//									}
//									break;	
//								}
								case 7:
								{
									if(System_process7() == 1)
									{
										stop_process();
										while(1); 						  	
									}
									break;	
								}
								case 8:
								{
									if(System_RND() == 1)
									{
										stop_process();
										while(1); 						  	
									}
									break;	
								}
								case 9:
								{
									if(KIDS_OPEN() == 1)
									{
										stop_process();
										while(1); 						  	
									}
									break;	
								}
							}
						}
					}								
				}
			}
		}
	}  	     
}


 unsigned int init_system(void)
{
	unsigned int delay_time=0;
	unsigned char t;
	unsigned int pos,i;

	//INITIALIZE THE INPUT PINS

	LPC_GPIO1->FIODIR &= ~(MANUAL_ARM_MOTOR|MANUAL_INDEX_MOTOR|MANUAL_HELMET_MOTOR1|MANUAL_HELMET_MOTOR2|MANUAL_NOZEL_MOTOR|MANUAL_FORWARD|MANUAL_REVERSE);
	LPC_GPIO0->FIODIR &= ~(INDEX_PROX1|INDEX_PROX2|ARM_LOWER_PROX1|ARM_LOWER_PROX2|ARM_LOWER_PROX3|ARM_UPPER_PROX1); 
	LPC_GPIO1->FIODIR &= ~(ARM_UPPER_PROX2|NOZEL_INDEX|MANUAL_BUTTON|START_BUTTON);
	LPC_GPIO3->FIODIR &= ~(AUTO_BUTTON|NOZEL_HOME);

	/*INITIALIZING THE I2C EXPANDER IC PINS AS OUTPUTS*/
	 
	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x18;		/* address */
	I2CMasterBuffer[PORT_USED][2] = 0x00;		/* Data0 */
	
	I2CEngine( PORT_USED );	
	delay_ms(100);


	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x19;		/* address */
	I2CMasterBuffer[PORT_USED][2] = 0x00;		/* Data0 */
	
	I2CEngine( PORT_USED );	
	delay_ms(100);

	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x1A;		/* address */
	I2CMasterBuffer[PORT_USED][2] = 0x00;		/* Data0 */
	
	I2CEngine( PORT_USED );
	delay_ms(100);

	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x1B;		/* address */
	I2CMasterBuffer[PORT_USED][2] = 0x00;		/* Data0 */
	
	I2CEngine( PORT_USED );
	delay_ms(100);

	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x1C;		/* address */
	I2CMasterBuffer[PORT_USED][2] = 0x00;		/* Data0 */
	
	I2CEngine( PORT_USED );
	delay_ms(100);


	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
	I2CMasterBuffer[PORT_USED][2] = 0x00;		/* Data0 */
	
	I2CEngine( PORT_USED );	
	delay_ms(100);
	
	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
	I2CMasterBuffer[PORT_USED][2] = 0x00;		/* Data0 */
	
	I2CEngine( PORT_USED );	
	delay_ms(100);

	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x0A;		/* address */
	I2CMasterBuffer[PORT_USED][2] = 0x00;		/* Data0 */
	
	I2CEngine( PORT_USED );
	delay_ms(100);

	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x0B;		/* address */
	I2CMasterBuffer[PORT_USED][2] = 0x00;		/* Data0 */
	
	I2CEngine( PORT_USED );
	delay_ms(100);

	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x0C;		/* address */
	I2CMasterBuffer[PORT_USED][2] = 0x00;		/* Data0 */
	
	I2CEngine( PORT_USED );
	delay_ms(100);


   	for ( i = 0; i < BUFSIZE_i2c; i++ )
	{
		I2CSlaveBuffer[PORT_USED][i] = 0x00;
	}
	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = 0XA0;
	I2CMasterBuffer[PORT_USED][1] = 0x00;		/* address */
	I2CMasterBuffer[PORT_USED][2] = 0x01;
	I2CEngine( PORT_USED );
	
	for ( i = 0; i < BUFSIZE_i2c; i++ )
	{
		I2CSlaveBuffer[PORT_USED][i] = 0x00;
	}


	I2CWriteLength[PORT_USED] = 0;
	I2CReadLength[PORT_USED] = 1;
	/* address */
	I2CMasterBuffer[PORT_USED][0] = 0XA1;
	I2CEngine( PORT_USED );

	for(pos=0,t=0x00;t < I2CSlaveBuffer[0][0];t++,pos++);


	if((LPC_GPIO3->FIOPIN & NOZEL_HOME))
	{
		if(pos == 1)
		{

			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0x04;
			I2CEngine( PORT_USED );
			delay_ms(100);

		}
		else //if(pos == 0) 
		{
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0x08;
			I2CEngine( PORT_USED );
			delay_ms(100);
		}
		delay_ms(100);
		delay_time=0;

		while(1)
		{
			delay_time++;
			if((!(LPC_GPIO3->FIOPIN & NOZEL_HOME)) && (!(LPC_GPIO1->FIOPIN & NOZEL_INDEX)))
			{
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );
				delay_ms(100);
				break;
			}
			else if(delay_time>40000000)
			{
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );
				delay_ms(100);
				return 1; 
			}
		}
	}

		//SAVE THE nozel position
	I2CWriteLength[PORT_USED] = 4;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = 0XA0;
	I2CMasterBuffer[PORT_USED][1] = 0x00;		/* address */
	I2CMasterBuffer[PORT_USED][2] = 0x01;		/* address */
	I2CMasterBuffer[PORT_USED][3] = 0x00;		/* Data0 */

		
	I2CEngine( PORT_USED );
//	delay_ms(250);

	delay_ms(200);

	if((LPC_GPIO0->FIOPIN & ARM_LOWER_PROX1))
	{
		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x88;
		I2CEngine( PORT_USED );
		delay_ms(100);
		delay_time=0;

		while(1)
		{
			delay_time++;
			if(!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX1)) 
			{
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );
				delay_ms(100);
				break;
			}
			else if(delay_time>60000000)
			{
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );
				delay_ms(100);

				LCD_CLEAR(); 
				
				LCD_SET_PAGE(PAGE1 + 0 , COL1);
				lcd_display_string("ARM MOTOR ");
				LCD_SET_PAGE(PAGE1 + 2 , COL1);
				lcd_display_string("FAULT");
				LCD_SET_PAGE(PAGE1 + 4, COL1);
				delay(100);

				return 1; 
			}
		}
	}
	delay_ms(200);


	if((!(LPC_GPIO0->FIOPIN & INDEX_PROX1)) || (!(LPC_GPIO0->FIOPIN & INDEX_PROX2)))
	{
		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x00;
		I2CEngine( PORT_USED );
		
		delay_ms(100);
		//ELECTROMAGNET
		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x40;
		I2CEngine( PORT_USED );
		delay_ms(100);

		if((!(LPC_GPIO0->FIOPIN & INDEX_PROX1)))
		{
			I2CWriteLength[PORT_USED] = 4;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = 0XA0;
			I2CMasterBuffer[PORT_USED][1] = 0x00;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0x00;		/* Data0 */
			I2CMasterBuffer[PORT_USED][3] = 0x01;		/* Data1 */
			
			I2CEngine( PORT_USED );
			delay_ms(100);
		}
		else if((!(LPC_GPIO0->FIOPIN & INDEX_PROX2)))
		{
			I2CWriteLength[PORT_USED] = 4;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = 0XA0;
			I2CMasterBuffer[PORT_USED][1] = 0x00;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0x00;		/* Data0 */
			I2CMasterBuffer[PORT_USED][3] = 0x02;		/* Data1 */
			
			I2CEngine( PORT_USED );
			delay_ms(100);
		}  		
	}
	else
	{
//		I2CWriteLength[PORT_USED] = 3;
//		I2CReadLength[PORT_USED] = 0;
//		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
//		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
//		I2CMasterBuffer[PORT_USED][2] = 0x00;
//		I2CEngine( PORT_USED );
//
//		delay_ms(5000);
//
//		for ( i = 0; i < BUFSIZE_i2c; i++ )
//		{
//			I2CSlaveBuffer[PORT_USED][i] = 0x00;
//		}
//		I2CWriteLength[PORT_USED] = 3;
//		I2CReadLength[PORT_USED] = 0;
//		I2CMasterBuffer[PORT_USED][0] = 0XA0;
//		I2CMasterBuffer[PORT_USED][1] = 0x00;		/* address */
//		I2CMasterBuffer[PORT_USED][2] = 0x00;
//		I2CEngine( PORT_USED );
//		
//		for ( i = 0; i < BUFSIZE_i2c; i++ )
//		{
//			I2CSlaveBuffer[PORT_USED][i] = 0x00;
//		}
//	
//	
//		I2CWriteLength[PORT_USED] = 0;
//		I2CReadLength[PORT_USED] = 1;
//		/* address */
//		I2CMasterBuffer[PORT_USED][0] = 0XA1;
//		I2CEngine( PORT_USED );
//	
//		for(pos=0,t=0x00;t < I2CSlaveBuffer[0][0];t++,pos++);
//
//
//		if(pos == 1)
//		{
//			I2CWriteLength[PORT_USED] = 3;
//			I2CReadLength[PORT_USED] = 0;
//			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
//			I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
//			I2CMasterBuffer[PORT_USED][2] = 0x14;
//			I2CEngine( PORT_USED );
//
//			delay_ms(3000);
//			
//			I2CWriteLength[PORT_USED] = 3;
//			I2CReadLength[PORT_USED] = 0;
//			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
//			I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
//			I2CMasterBuffer[PORT_USED][2] = 0x11;
//			I2CEngine( PORT_USED );
//
//			delay_time=0;
//			while(1)
//			{
//				delay_time++;
//				if((!(LPC_GPIO0->FIOPIN & INDEX_PROX2)) )
//				{
//					//delay_ms(2000);
//					I2CWriteLength[PORT_USED] = 3;
//					I2CReadLength[PORT_USED] = 0;
//					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
//					I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
//					I2CMasterBuffer[PORT_USED][2] = 0x00;
//					I2CEngine( PORT_USED );
//
//					delay_ms(50);
//
//					I2CWriteLength[PORT_USED] = 4;
//					I2CReadLength[PORT_USED] = 0;
//					I2CMasterBuffer[PORT_USED][0] = 0XA0;
//					I2CMasterBuffer[PORT_USED][1] = 0x00;		/* address */
//					I2CMasterBuffer[PORT_USED][2] = 0x00;		/* Data0 */
//					I2CMasterBuffer[PORT_USED][3] = 0x02;		/* Data1 */
//					
//					I2CEngine( PORT_USED );
//					delay_ms(100);
//					break;
//				}
//				else if(delay_time > 40000000)
//				{
//					I2CWriteLength[PORT_USED] = 3;
//					I2CReadLength[PORT_USED] = 0;
//					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
//					I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
//					I2CMasterBuffer[PORT_USED][2] = 0x00;
//					I2CEngine( PORT_USED );
//					return 1; 
//				}
//			}
//		}
//		else if(pos == 2)
//		{ 			
//			I2CWriteLength[PORT_USED] = 3;
//			I2CReadLength[PORT_USED] = 0;
//			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
//			I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
//			I2CMasterBuffer[PORT_USED][2] = 0x24;
//			I2CEngine( PORT_USED );
//
//			delay_ms(3000);
//			
//			I2CWriteLength[PORT_USED] = 3;
//			I2CReadLength[PORT_USED] = 0;
//			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
//			I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
//			I2CMasterBuffer[PORT_USED][2] = 0x21;
//			I2CEngine( PORT_USED );
//
//			delay_time=0;
//			while(1)
//			{
//				delay_time++;
//				if((!(LPC_GPIO0->FIOPIN & INDEX_PROX1)) )
//				{
//					//delay_ms(2000);
//					I2CWriteLength[PORT_USED] = 3;
//					I2CReadLength[PORT_USED] = 0;
//					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
//					I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
//					I2CMasterBuffer[PORT_USED][2] = 0x00;
//					I2CEngine( PORT_USED );
//					
//					I2CWriteLength[PORT_USED] = 4;
//					I2CReadLength[PORT_USED] = 0;
//					I2CMasterBuffer[PORT_USED][0] = 0XA0;
//					I2CMasterBuffer[PORT_USED][1] = 0x00;		/* address */
//					I2CMasterBuffer[PORT_USED][2] = 0x00;		/* Data0 */
//					I2CMasterBuffer[PORT_USED][3] = 0x01;		/* Data1 */
//					
//					I2CEngine( PORT_USED );
//					delay_ms(100);
//					break;
//				}
//				else if(delay_time>40000000)
//				{
//					I2CWriteLength[PORT_USED] = 3;
//					I2CReadLength[PORT_USED] = 0;
//					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
//					I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
//					I2CMasterBuffer[PORT_USED][2] = 0x00;
//					I2CEngine( PORT_USED );
//					return 1; 
//				}
//			}	
//		}
//		else
//		{
//			I2CWriteLength[PORT_USED] = 3;
//			I2CReadLength[PORT_USED] = 0;
//			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
//			I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
//			I2CMasterBuffer[PORT_USED][2] = 0x24;
//			I2CEngine( PORT_USED );
//
//			delay_ms(3000);
			//delay_ms(250);
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0x21;
			I2CEngine( PORT_USED );
			delay_ms(100);

			delay_time=0;
			while(1)
			{
				delay_time++;
				if((!(LPC_GPIO0->FIOPIN & INDEX_PROX1)) )
				{
					//delay_ms(2000);
					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
					I2CMasterBuffer[PORT_USED][2] = 0x00;
					I2CEngine( PORT_USED );
					delay_ms(100);
					
					I2CWriteLength[PORT_USED] = 4;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = 0XA0;
					I2CMasterBuffer[PORT_USED][1] = 0x00;		/* address */
					I2CMasterBuffer[PORT_USED][2] = 0x00;		/* Data0 */
					I2CMasterBuffer[PORT_USED][3] = 0x01;		/* Data1 */
					
					I2CEngine( PORT_USED );
					delay_ms(100);

					delay_time=0;
					
					break;
				}
				else if(delay_time>60000000)
				{
					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
					I2CMasterBuffer[PORT_USED][2] = 0x00;
					I2CEngine( PORT_USED );

					LCD_CLEAR(); 
				
				LCD_SET_PAGE(PAGE1 + 0 , COL1);
				lcd_display_string("INDEX MOTOR ");
				LCD_SET_PAGE(PAGE1 + 2 , COL1);
				lcd_display_string("FAULT");
				LCD_SET_PAGE(PAGE1 + 4, COL1);
				delay(100);

					return 1; 
				}
			}
		//}
		//ELECTROMAGNET
		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x40;
		I2CEngine( PORT_USED );
		delay(100);							
		
	}
	return 0;
}

void stop_process(void)
{
	
	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
	I2CMasterBuffer[PORT_USED][2] = 0x00;
	I2CEngine( PORT_USED );
	delay(100);
	
	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
	I2CMasterBuffer[PORT_USED][2] = 0x80;
	I2CEngine( PORT_USED );
	delay(100);
	
	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x0A;		/* address */
	I2CMasterBuffer[PORT_USED][2] = 0x00;
	I2CEngine( PORT_USED );
	delay(100);

	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x0B;		/* address */
	I2CMasterBuffer[PORT_USED][2] = 0x00;
	I2CEngine( PORT_USED );
	delay(100);

	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x0C;		/* address */
	I2CMasterBuffer[PORT_USED][2] = 0x00;
	I2CEngine( PORT_USED );
	delay(100);

	return;
}


unsigned int System_status(void)
{
	if((LPC_GPIO0->FIOPIN & ARM_LOWER_PROX1)) 
	{
		return 1;
		
	}
	if((LPC_GPIO3->FIOPIN & NOZEL_HOME))
	{			
		return 1;
	}
	if(((LPC_GPIO0->FIOPIN & INDEX_PROX1)) && ((LPC_GPIO0->FIOPIN & INDEX_PROX2)))
	{			
		return 1; 		
	}

	return 0;

}

unsigned int System_process1(void)
{
	unsigned int flag1,flag2,helmet1_flag;
	unsigned int delay_time;
	unsigned char port_value=0x00;
	
	
	helmet1_flag=0;

	
	if(System_status() == 1)
	{
		return 1;
	}

	//ELECTROMAGNET ON

	port_value|= 0x40;

	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
	I2CMasterBuffer[PORT_USED][2] = port_value;
	I2CEngine( PORT_USED );	

	delay_ms(250);

		if((!(LPC_GPIO0->FIOPIN & INDEX_PROX2)))
		{
			//HELMET1 ON
			//port_value|= 0x02;
			port_value|= 0x01;
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
			I2CMasterBuffer[PORT_USED][2] = port_value;
			I2CEngine( PORT_USED );
			delay(100);	

			helmet1_flag=1;
		}								  
		else if((!(LPC_GPIO0->FIOPIN & INDEX_PROX1)))
		{
			//HELMET2 ON

			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x0A;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0X04;
			I2CEngine( PORT_USED );
			delay(100);

		}
 	   	
		
//		//ON THE PAINT 
//		port_value|= 0x10;
//
//		I2CWriteLength[PORT_USED] = 3;
//		I2CReadLength[PORT_USED] = 0;
//		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
//		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
//		I2CMasterBuffer[PORT_USED][2] = port_value; 
//		I2CEngine( PORT_USED );	
		delay_ms(500);	 //DELAY AFTER THE PAINT IS ON
		

		//ON THE ARM MOTOR WITH 320 RPM 

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x48;
		I2CEngine( PORT_USED );	
		delay(100);
		
		delay_ms(500);

		flag1=0;
		flag2=0;
		

		//NOZEL MOTOR ON
		port_value |= 0x04;
		//port_value |= 0x10;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );											  
		delay_ms(1000);

		port_value |= 0x10;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );											  
		delay_ms(250);
		//delay_ms(4000);		 //DELAY TO MOVE THE NOZEL MOTOR TO HORIZONTAL
		
		delay_time=0;

   		while(1)
		{
			delay_time++;
			
			if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX2))  )
			{
				delay_ms(100);
				if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX2)))
				{
					port_value ^= 0x04;
					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
					I2CMasterBuffer[PORT_USED][2] = port_value;
					I2CEngine( PORT_USED );						
					delay_ms(100); 	
					break;
				}			
			}			
			else if(delay_time > 30000000)	  
			{	
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay(100);

				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay(100);		 
				
				return 1;
			}
		}
			
		 
		delay_time=0;

   		while(1)
		{
			delay_time++;
			
			if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX3))  )
			{
				delay_ms(100);
				if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX3)))
				{
					
					break;
				}			
			}			
			else if(delay_time>30000000)	  
			{	
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay(100);

				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );
				delay(100);			 
				
				return 1;
			}
		}

//		//NOZEL MOTOR ON
		port_value |= 0X04;
		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );	
		delay(100);

		delay_time=0;
		flag1=0;
		flag2=0;

   		while(1)
		{
			delay_time++;
			
			if((!(LPC_GPIO1->FIOPIN & ARM_UPPER_PROX2)) && (flag1 == 0) )
			{
				delay_ms(100);
				if((!(LPC_GPIO1->FIOPIN & ARM_UPPER_PROX2)) && (flag1 == 0) )
				{
					flag1=1;
					break;
				//	delay_ms(100); 	
				}			
			}
			if((!(LPC_GPIO1->FIOPIN & NOZEL_INDEX)) && (flag1 == 0 ))
			{
				delay_ms(100);
				if((!(LPC_GPIO1->FIOPIN & NOZEL_INDEX)) && (flag1 == 0 ))
				{
					port_value ^= 0x04;

					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
					I2CMasterBuffer[PORT_USED][2] = port_value;
					I2CEngine( PORT_USED );	
					delay_ms(100);	
					flag2=1;
					
				}				
			}			
			if(delay_time>30000000)	  
			{	
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay_ms(100);

				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay_ms(100);		 
				
				return 1;
			}
		}

		//ARM CYLINDER ON		
		port_value |= 0X20;
		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );	
		delay_ms(100);
		delay_time=0;
		flag1=0;

   		while(1)
		{
			delay_time++;
			
			if((!(LPC_GPIO0->FIOPIN & ARM_UPPER_PROX1)) && (flag1 == 0) )
			{
				delay_ms(100);
				if((!(LPC_GPIO0->FIOPIN & ARM_UPPER_PROX1)) && (flag1 == 0) )
				{
					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
					I2CMasterBuffer[PORT_USED][2] = 0x00;
					I2CEngine( PORT_USED );	
					delay(100);
					flag1=1;
					
				}			
			}
			if((!(LPC_GPIO1->FIOPIN & NOZEL_INDEX)) && (flag2 == 0 ))
			{
				delay_ms(100);
				if((!(LPC_GPIO1->FIOPIN & NOZEL_INDEX)) && (flag2 == 0 ))
				{
					port_value ^= 0x04;

					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
					I2CMasterBuffer[PORT_USED][2] = port_value;
					I2CEngine( PORT_USED );	
					delay(100);	
					flag2=1;
					
				}				
			}
			if((flag1 == 1) && (flag2 == 1))
			{
			   	
				delay_ms(200);	   
				break;
			}
			if(delay_time>40000000)	  
			{	
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay_ms(100);

				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay_ms(100);		 
				
				return 1;
			}
		}

		
		//ARM CYLINDER OFF

		port_value ^= 0X20;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );		
		delay_ms(200);

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x88;
		I2CEngine( PORT_USED );		

	   
		delay_ms(2000);   //DELAY TO MOVE THE ARM WITHOUT CHANGING THE NOZEL

		//NOZEL MOTOR ON RVS
		port_value |= 0X08;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );		
	
		delay_ms(2000);		  //SIMPLE DELAY
		
		
		flag1=0;
		flag2=0;
   		delay_time=0;

   		while(1)
		{
			delay_time++;
			if(delay_time>40000000)	  //check the time
			{			 
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );
				delay_ms(100);
						
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay_ms(100);	

				return 1;
			}
			if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX1)) && (flag1 == 0 ))
			{
				delay_ms(100);
				if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX1)) && (flag1 == 0 ))
				{
					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
					I2CMasterBuffer[PORT_USED][2] = 0x00;
					I2CEngine( PORT_USED );	
					delay_ms(100);	
					
					//ELECTROMAGNET OFF
					port_value ^=0X40;

					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
					I2CMasterBuffer[PORT_USED][2] = port_value;
					I2CEngine( PORT_USED );		
					flag1=1;
					delay_ms(100);
				}
	
			}
			if((!(LPC_GPIO3->FIOPIN & NOZEL_HOME)) && (flag2 == 0 ))
			{
				delay_ms(100);	
				if((!(LPC_GPIO3->FIOPIN & NOZEL_HOME)) && (flag2 == 0 ))
				{
				   	//NOZEL MOTOR OFF
					port_value ^= 0X08;
					//port_value ^= 0X10;
					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
					I2CMasterBuffer[PORT_USED][2] = port_value;
					I2CEngine( PORT_USED );	
					delay(100);	
					flag2=1;
					
				}
			}		
			if((flag1 == 1) && (flag2 == 1))
			{					
				//delay_ms(500);
				break;
			}
		}

		//PAINT SOLONOID OFF
		port_value ^= 0X10;		

		if(helmet1_flag == 1)
		{
		    port_value ^= 0X01;
		}
		else
		{
			
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x0A;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0X00;
			I2CEngine( PORT_USED );	
			delay_ms(100);
		}

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );		

		delay_ms(500);

		if((!(LPC_GPIO0->FIOPIN & INDEX_PROX1)))
		{
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0x14;
			I2CEngine( PORT_USED );

			delay_ms(4000);
			
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0x11;
			I2CEngine( PORT_USED );
			delay_ms(100);

			delay_time=0;
			while(1)
			{
				delay_time++;
				
				if((!(LPC_GPIO0->FIOPIN & INDEX_PROX2)) )
				{
					delay_ms(100);
					if((!(LPC_GPIO0->FIOPIN & INDEX_PROX2)) )
					{
						//delay_ms(2000);
						I2CWriteLength[PORT_USED] = 3;
						I2CReadLength[PORT_USED] = 0;
						I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
						I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
						I2CMasterBuffer[PORT_USED][2] = 0x00;
						I2CEngine( PORT_USED );
						delay_ms(100);

						delay_time=0;						
						break;
					}					
				}
				else if(delay_time>80000000)	  //check the time
				{			 
					return 1;
				}
			}
		}
		else if((!(LPC_GPIO0->FIOPIN & INDEX_PROX2)))
		{
			
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0x24;
			I2CEngine( PORT_USED );

			delay_ms(4000);
			
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0x21;
			I2CEngine( PORT_USED );
			delay_ms(100);

			delay_time=0;
			while(1)
			{
				delay_time++;
				
				if((!(LPC_GPIO0->FIOPIN & INDEX_PROX1)) )
				{
					delay_ms(100);
					if((!(LPC_GPIO0->FIOPIN & INDEX_PROX1)) )
					{
						//delay_ms(2000);
						I2CWriteLength[PORT_USED] = 3;
						I2CReadLength[PORT_USED] = 0;
						I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
						I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
						I2CMasterBuffer[PORT_USED][2] = 0x00;
						I2CEngine( PORT_USED );	
						delay_ms(100);					
						//delay_ms(10);
						delay_time=0;						
									
						break;
					}
				}
				else if(delay_time>80000000)	  //check the time
				{			 
					return 1;
				}
			}	
		}
		
	port_value |= 0X40;
	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
	I2CMasterBuffer[PORT_USED][2] = port_value;
	I2CEngine( PORT_USED );	
	delay_ms(100);
	
	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x0A;		/* address */
	I2CMasterBuffer[PORT_USED][2] = 0X02;
	I2CEngine( PORT_USED );	
				 		
	delay_ms(100);

	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x0A;		/* address */
	I2CMasterBuffer[PORT_USED][2] = 0X00;
	I2CEngine( PORT_USED );	
	delay_ms(100);

	return 0;

}

unsigned int System_process2(void) //CRUISER
{
	unsigned int flag1,flag2,helmet1_flag;
	unsigned int delay_time;
	unsigned char port_value=0x00;
	
	
	helmet1_flag=0;

	
	if(System_status() == 1)
	{
		return 1;
	}

	port_value |= 0x40;
	port_value |= 0X20;

	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
	I2CMasterBuffer[PORT_USED][2] = port_value;
	I2CEngine( PORT_USED );	

	delay_ms(250);

		if((!(LPC_GPIO0->FIOPIN & INDEX_PROX2)))
		{
			//HELMET1 ON
			//port_value|= 0x02;
			port_value|= 0x01;
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
			I2CMasterBuffer[PORT_USED][2] = port_value;
			I2CEngine( PORT_USED );	
			delay_ms(100);

			helmet1_flag=1;
		}								  
		else if((!(LPC_GPIO0->FIOPIN & INDEX_PROX1)))
		{
			//HELMET2 ON

			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x0A;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0X04;
			I2CEngine( PORT_USED );	 
			delay_ms(100);

		}

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x48;
		I2CEngine( PORT_USED );	
		delay_ms(500);

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x00;
		I2CEngine( PORT_USED );	
		delay_ms(100);

		//SAVE THE nozel position
		I2CWriteLength[PORT_USED] = 4;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = 0XA0;
		I2CMasterBuffer[PORT_USED][1] = 0x00;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x01;		/* address */
		I2CMasterBuffer[PORT_USED][3] = 0x01;		/* Data0 */
	
			
		I2CEngine( PORT_USED );
		delay_ms(250);

	   	port_value |= 0X08;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );		
	
		delay_ms(3500);	 //ANGLE CHANGED 1500
		
		
		//ON THE PAINT 
		port_value ^= 0X08;
		port_value |= 0x10;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value; 
		I2CEngine( PORT_USED );	
		
		delay_ms(5000);	

//		//OFF THE PAINT 
//		port_value ^= 0x10;
//
//		I2CWriteLength[PORT_USED] = 3;
//		I2CReadLength[PORT_USED] = 0;
//		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
//		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
//		I2CMasterBuffer[PORT_USED][2] = port_value; 
//		I2CEngine( PORT_USED );	
//		delay_ms(1000);


		port_value |= 0X04;
		port_value ^= 0X20;
		port_value ^= 0x10;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );		
	
		delay_ms(2500);	
		
   		delay_time=0;

   		while(1)
		{
			delay_time++;
			if(delay_time>40000000)	  //check the time
			{			 
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );
				delay_ms(100);
						
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );
				delay_ms(100);		

				return 1;
			}	 			
			else if((!(LPC_GPIO3->FIOPIN & NOZEL_HOME)) )
			{
				delay_ms(100);	
				if((!(LPC_GPIO3->FIOPIN & NOZEL_HOME)) )
				{
				   	//NOZEL MOTOR OFF
					port_value ^= 0X04;
					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
					I2CMasterBuffer[PORT_USED][2] = port_value;
					I2CEngine( PORT_USED );							
					delay_ms(500);
					break;
				}
			}				
		}

	   	
		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x48;
		I2CEngine( PORT_USED );	
		delay_ms(100);


		

		flag1=0;
		flag2=0;
	

	
		 //SAVE THE nozel position
		I2CWriteLength[PORT_USED] = 4;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = 0XA0;
		I2CMasterBuffer[PORT_USED][1] = 0x00;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x01;		/* address */
		I2CMasterBuffer[PORT_USED][3] = 0x00;		/* Data0 */
	
			
		I2CEngine( PORT_USED );
		delay_ms(250);
	

		//NOZEL MOTOR ON
		port_value |= 0x04;
		//port_value |= 0x10;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );	

		delay_ms(100);		 		
			
		//NOZEL MOTOR OFF
//		port_value ^= 0x04;
//		I2CWriteLength[PORT_USED] = 3;
//		I2CReadLength[PORT_USED] = 0;
//		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
//		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
//		I2CMasterBuffer[PORT_USED][2] = port_value;
//		I2CEngine( PORT_USED );	
//		delay_ms(100);

		delay_time=0;

   		while(1)
		{
			delay_time++;
			
			if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX2))  )
			{
				delay_ms(100);
				if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX2)))
				{
					port_value ^= 0x04;
					port_value |= 0x10;
					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
					I2CMasterBuffer[PORT_USED][2] = port_value;
					I2CEngine( PORT_USED );						
					delay_ms(100); 	
					break;
				}			
			}			
			else if(delay_time > 30000000)	  
			{	
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay(100);

				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay(100);		 
				
				return 1;
			}
		}

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x42;
		I2CEngine( PORT_USED );	
		delay_ms(100);
	

		delay_time=0;

   		while(1)
		{
			delay_time++;
			if(delay_time > 120000000)	  //check the time
			{			 
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );
				delay_ms(100);
						
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );		
				delay_ms(100);

				return 1;
			}	 			
			else if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX3)) )
			{
				delay_ms(100);	
				if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX3)) )
				{
				   
					break;
				}
			}				
		}

//		//NOZEL MOTOR ON
		port_value |= 0X04;
		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );	
		delay_ms(100);


		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x48;
		I2CEngine( PORT_USED );	
		delay_ms(100);


		delay_time=0;
		flag1=0;
		flag2=0;

   		while(1)
		{
			delay_time++;
			
			if((!(LPC_GPIO1->FIOPIN & ARM_UPPER_PROX2)) && (flag1 == 0) )
			{
				delay_ms(100);
				if((!(LPC_GPIO1->FIOPIN & ARM_UPPER_PROX2)) && (flag1 == 0) )
				{
					flag1=1;
					break;
				//	delay_ms(100); 	
				}			
			}
			if((!(LPC_GPIO1->FIOPIN & NOZEL_INDEX)) && (flag1 == 0 ))
			{
				delay_ms(100);
				if((!(LPC_GPIO1->FIOPIN & NOZEL_INDEX)) && (flag1 == 0 ))
				{
					port_value ^= 0x04;

					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
					I2CMasterBuffer[PORT_USED][2] = port_value;
					I2CEngine( PORT_USED );	
					delay_ms(100);	
					flag2=1;
					
				}				
			}			
			if(delay_time>30000000)	  
			{	
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay_ms(100);

				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay_ms(100);		 
				
				return 1;
			}
		}

		//ARM CYLINDER ON		
		port_value |= 0X20;
		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );	
	    delay_ms(100);

		delay_time=0;
		flag1=0;
   		while(1)
		{
			delay_time++;
			
			if((!(LPC_GPIO0->FIOPIN & ARM_UPPER_PROX1)) && (flag1 == 0) )
			{
				delay_ms(100);
				if((!(LPC_GPIO0->FIOPIN & ARM_UPPER_PROX1)) && (flag1 == 0) )
				{
					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
					I2CMasterBuffer[PORT_USED][2] = 0x00;
					I2CEngine( PORT_USED );	
					delay_ms(100);
					flag1=1;						
				}			
			}
			if((!(LPC_GPIO1->FIOPIN & NOZEL_INDEX)) && (flag2 == 0 ))
			{
				delay_ms(100);
				if((!(LPC_GPIO1->FIOPIN & NOZEL_INDEX)) && (flag2 == 0 ))
				{
					port_value ^= 0x04;

					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
					I2CMasterBuffer[PORT_USED][2] = port_value;
					I2CEngine( PORT_USED );	
					delay_ms(100);	
					flag2=1;					
				}				
			}
			if((flag1 == 1) && (flag2 == 1))
			{
			   	
				delay_ms(500);	   //10000
				//LPC_GPIO2->FIOCLR 	 = 	SOLONID_SIGNAL;
				break;
			}
			if(delay_time>40000000)	  //check the time
			{	
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay_ms(100);

				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay_ms(100);		 
				
				return 1;
			}
		}		

		port_value ^= 0X20;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );		
		delay_ms(100);


		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x88;
		I2CEngine( PORT_USED );		

	   
		delay_ms(100);  

		//NOZEL MOTOR ON RVS
		port_value |= 0X08;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );		
		delay_ms(100);

		delay_time=0;

   		while(1)
		{
			delay_time++;
			if(delay_time > 20000000)	  //check the time
			{			 
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );
				delay_ms(100);
						
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );		
				delay_ms(100);

				return 1;
			}	 			
			else if((!(LPC_GPIO1->FIOPIN & ARM_UPPER_PROX2)) )
			{
				delay_ms(100);	
				if((!(LPC_GPIO1->FIOPIN & ARM_UPPER_PROX2)) )
				{
				   
					break;
				}
			}				
		}

		delay_ms(1000);

		port_value ^= 0X08;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );	
		delay_ms(100);		
		
	
		delay_time=0;

   		while(1)
		{
			delay_time++;
			if(delay_time>120000000)	  //check the time
			{			 
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );
				delay_ms(100);
						
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );		
				delay_ms(100);

				return 1;
			}	 			
			else if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX3)) )
			{
				delay_ms(100);	
				if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX3)) )
				{
				   
					break;
				}
			}				
		}

		//NOZEL MOTOR ON RVS
		port_value |= 0X08;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );	

		delay_ms(100);
	   	
	
		flag1=0;
		flag2=0;
   		delay_time=0;

   		while(1)
		{
			delay_time++;
			if(delay_time>40000000)	  //check the time
			{			 
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );
				delay_ms(100);
						
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay_ms(100);	

				return 1;
			}
			if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX1)) && (flag1 == 0 ))
			{
				delay_ms(100);
				if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX1)) && (flag1 == 0 ))
				{
					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
					I2CMasterBuffer[PORT_USED][2] = 0x00;
					I2CEngine( PORT_USED );		
					delay_ms(100);
					//ELECTROMAGNET OFF
					port_value ^=0X40;

					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
					I2CMasterBuffer[PORT_USED][2] = port_value;
					I2CEngine( PORT_USED );		
					flag1=1;
					delay_ms(100);
				}
	
			}
			if((!(LPC_GPIO3->FIOPIN & NOZEL_HOME)) && (flag2 == 0 ))
			{
				delay_ms(100);	
				if((!(LPC_GPIO3->FIOPIN & NOZEL_HOME)) && (flag2 == 0 ))
				{
				   	//NOZEL MOTOR OFF
					port_value ^= 0X08;					
					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
					I2CMasterBuffer[PORT_USED][2] = port_value;
					I2CEngine( PORT_USED );		
					flag2=1;
					delay_ms(100);
				}
			}		
			if((flag1 == 1) && (flag2 == 1))
			{  				
				//delay_ms(500);
				break;
			}
		}

//		//PAINT SOLONOID OFF
		port_value ^= 0X10;	 		

		if(helmet1_flag == 1)
		{
		    port_value ^= 0X01;
		}
		else
		{
			
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x0A;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0X00;
			I2CEngine( PORT_USED );	
			delay_ms(100);
		}

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );		

		delay_ms(500);

		if((!(LPC_GPIO0->FIOPIN & INDEX_PROX1)))
		{
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0x14;
			I2CEngine( PORT_USED );

			delay_ms(4000);
			
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0x11;
			I2CEngine( PORT_USED );
			delay_ms(100);

			delay_time=0;
			while(1)
			{
				delay_time++;
				
				if((!(LPC_GPIO0->FIOPIN & INDEX_PROX2)) )
				{
					delay_ms(100);
					if((!(LPC_GPIO0->FIOPIN & INDEX_PROX2)) )
					{
						//delay_ms(2000);
						I2CWriteLength[PORT_USED] = 3;
						I2CReadLength[PORT_USED] = 0;
						I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
						I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
						I2CMasterBuffer[PORT_USED][2] = 0x00;
						I2CEngine( PORT_USED );
						delay_ms(100);

						delay_time=0;
						//delay_ms(10);	 					
						
						break;
					}					
				}
				else if(delay_time>80000000)	  //check the time
				{			 
					return 1;
				}
			}
		}
		else if((!(LPC_GPIO0->FIOPIN & INDEX_PROX2)))
		{
			
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0x24;
			I2CEngine( PORT_USED );

			delay_ms(4000);
			
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0x21;
			I2CEngine( PORT_USED );
			delay_ms(100);

			delay_time=0;
			while(1)
			{
				delay_time++;
				
				if((!(LPC_GPIO0->FIOPIN & INDEX_PROX1)) )
				{
					delay_ms(100);
					if((!(LPC_GPIO0->FIOPIN & INDEX_PROX1)) )
					{
						//delay_ms(2000);
						I2CWriteLength[PORT_USED] = 3;
						I2CReadLength[PORT_USED] = 0;
						I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
						I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
						I2CMasterBuffer[PORT_USED][2] = 0x00;
						I2CEngine( PORT_USED );						
						delay_ms(100);
						
						delay_time=0;						
									
						break;
					}
				}
				else if(delay_time>80000000)	  //check the time
				{			 
					return 1;
				}
			}	
		}
		
	port_value |= 0X40;
	port_value |= 0X20;

	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
	I2CMasterBuffer[PORT_USED][2] = port_value;
	I2CEngine( PORT_USED );		
	delay_ms(100);
	
	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x0A;		/* address */
	I2CMasterBuffer[PORT_USED][2] = 0X02;
	I2CEngine( PORT_USED );	
				 		
	delay_ms(100);

	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x0A;		/* address */
	I2CMasterBuffer[PORT_USED][2] = 0X00;
	I2CEngine( PORT_USED );	   
	delay_ms(100);


	return 0;

}

unsigned int System_process3(void)
{
	unsigned int flag1,flag2,helmet1_flag;
	unsigned int delay_time;
	unsigned char port_value=0x00;
	
	
	helmet1_flag=0;

	
	if(System_status() == 1)
	{
		return 1;
	}

		//ELECTROMAGNET ON

	port_value |= 0x40;
	//port_value |= 0X20;

	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
	I2CMasterBuffer[PORT_USED][2] = port_value;
	I2CEngine( PORT_USED );	

	delay_ms(250);

		if((!(LPC_GPIO0->FIOPIN & INDEX_PROX2)))
		{
			
			port_value|= 0x01;
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
			I2CMasterBuffer[PORT_USED][2] = port_value;
			I2CEngine( PORT_USED );	
			delay_ms(100);

			helmet1_flag=1;
		}								  
		else if((!(LPC_GPIO0->FIOPIN & INDEX_PROX1)))
		{
			//HELMET2 ON

			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x0A;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0X04;
			I2CEngine( PORT_USED );	
			delay_ms(100);


		}

		delay_ms(1000);
		port_value|= 0x10;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value; 
		I2CEngine( PORT_USED );	
		delay_ms(100);


		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x48;
		I2CEngine( PORT_USED );	
		delay_ms(100);
	

		flag1=0;
		flag2=0;
	

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x42;
		I2CEngine( PORT_USED );	
		delay_ms(100);
		
		port_value |= 0x04;
		

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );	

		delay_ms(2000);

	   port_value ^= 0x04;
		

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );	

	   delay_ms(6000);

		
		port_value |= 0x04;
		

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );	

		delay_ms(3000);		 

		port_value ^= 0x04;
		port_value |= 0X20;

	
		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );	

		delay_ms(17000);  

//		//NOZEL MOTOR ON
		port_value |= 0X04;
		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );	
		delay_ms(100);

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x48;
		I2CEngine( PORT_USED );	

		delay_ms(2000);

			//NOZEL MOTOR ON
		port_value ^= 0X04;
		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );	
		delay_ms(100);
	   
	 	flag1=0;
		delay_time=0;

   		while(1)
		{
			delay_time++;
			
			if((!(LPC_GPIO0->FIOPIN & ARM_UPPER_PROX1)) && (flag1 == 0) )
			{
				delay_ms(100);
				if((!(LPC_GPIO0->FIOPIN & ARM_UPPER_PROX1)) && (flag1 == 0) )
				{
					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
					I2CMasterBuffer[PORT_USED][2] = 0x00;
					I2CEngine( PORT_USED );	
					flag1=1;
					delay_ms(3000); 	
					break;
				}			
			}
			else if(delay_time>40000000)	  //check the time
			{	
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay_ms(100);

				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );
				delay_ms(100);			 
				
				return 1;
			}
		}		

		//ARM CYLINDER OFF
		port_value ^= 0X20;
		port_value |= 0X04;

		port_value ^= 0X10;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );
		delay_ms(100);

		delay_time=0;
		flag2=0;
   		while(1)
		{
			delay_time++;
			
			if((!(LPC_GPIO1->FIOPIN & NOZEL_INDEX)) && (flag2 == 0 ))
			{
				delay_ms(100);
				if((!(LPC_GPIO1->FIOPIN & NOZEL_INDEX)) && (flag2 == 0 ))
				{
					port_value ^= 0x04;

					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
					I2CMasterBuffer[PORT_USED][2] = port_value;
					I2CEngine( PORT_USED );	
					delay_ms(100);	
					flag2=1;
					//delay_ms(500);
					break;
				}				
			}
			else if(delay_time>40000000)	  //check the time
			{	
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay_ms(100);

				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );			 
				delay_ms(100);
				
				return 1;
			}
		}	 			

		port_value |= 0X10;


		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );	
		delay_ms(100);

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x88;
		I2CEngine( PORT_USED );		

	   
		delay_ms(1000);  

		//NOZEL MOTOR ON RVS
		port_value |= 0X08;
	   	

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );	
		delay_ms(100);	
	
		flag1=0;
		flag2=0;
   		delay_time=0;

   		while(1)
		{
			delay_time++;
			if(delay_time>40000000)	  //check the time
			{			 
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );
				delay_ms(100);
						
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay_ms(100);	

				return 1;
			}
			if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX1)) && (flag1 == 0 ))
			{
				delay_ms(100);
				if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX1)) && (flag1 == 0 ))
				{
					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
					I2CMasterBuffer[PORT_USED][2] = 0x00;
					I2CEngine( PORT_USED );						
					delay_ms(100);
					flag1=1;
				}
	
			}
			if((!(LPC_GPIO3->FIOPIN & NOZEL_HOME)) && (flag2 == 0 ))
			{
				delay_ms(100);	
				if((!(LPC_GPIO3->FIOPIN & NOZEL_HOME)) && (flag2 == 0 ))
				{
				   	//NOZEL MOTOR OFF
					port_value ^= 0X08;
					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
					I2CMasterBuffer[PORT_USED][2] = port_value;
					I2CEngine( PORT_USED );					
					delay_ms(100);
					flag2=1;
				}
			}		
			if((flag1 == 1) && (flag2 == 1))
			{ 				
				delay_ms(100);
				break;
			}
		}

		port_value |= 0X08;
		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );	

		delay_ms(2000);

		port_value ^= 0X08;
		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );	

		delay_ms(1000);

		port_value ^= 0X10;
		port_value |= 0X04;

		if(helmet1_flag == 1)
		{
		    port_value ^= 0X01;
		}
		else
		{ 			
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x0A;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0X00;
			I2CEngine( PORT_USED );	
			delay_ms(100);
		}

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );	
		delay_ms(100);	


		flag1=0;
		flag2=0;
   		delay_time=0;

   		while(1)
		{
			delay_time++;
			if(delay_time>40000000)	  //check the time
			{			 
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );
				delay_ms(100);
						
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay_ms(100);	

				return 1;
			}
			
			if((!(LPC_GPIO3->FIOPIN & NOZEL_HOME)) && (flag2 == 0 ))
			{
				delay_ms(100);	
				if((!(LPC_GPIO3->FIOPIN & NOZEL_HOME)) && (flag2 == 0 ))
				{
				   	//NOZEL MOTOR OFF
					port_value ^= 0X08;
					port_value ^=0X40;
	
					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
					I2CMasterBuffer[PORT_USED][2] = port_value;
					I2CEngine( PORT_USED );		
					flag2=1;
					delay_ms(100);
					break;
				}
			}		
			
		}


		delay_ms(200);

		if((!(LPC_GPIO0->FIOPIN & INDEX_PROX1)))
		{
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0x14;
			I2CEngine( PORT_USED );

			delay_ms(4000);
			
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0x11;
			I2CEngine( PORT_USED );
			delay_ms(100);

			delay_time=0;
			while(1)
			{
				delay_time++;
				
				if((!(LPC_GPIO0->FIOPIN & INDEX_PROX2)) )
				{
					delay_ms(100);
					if((!(LPC_GPIO0->FIOPIN & INDEX_PROX2)) )
					{
						//delay_ms(2000);
						I2CWriteLength[PORT_USED] = 3;
						I2CReadLength[PORT_USED] = 0;
						I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
						I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
						I2CMasterBuffer[PORT_USED][2] = 0x00;
						I2CEngine( PORT_USED );
						delay_ms(100);
						delay_time=0;
						//delay_ms(10);	 					
						
						break;
					}					
				}
				else if(delay_time>80000000)	  //check the time
				{			 
					return 1;
				}
			}
		}
		else if((!(LPC_GPIO0->FIOPIN & INDEX_PROX2)))
		{
			
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0x24;
			I2CEngine( PORT_USED );

			delay_ms(4000);
			
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0x21;
			I2CEngine( PORT_USED );
			delay_ms(100);

			delay_time=0;
			while(1)
			{
				delay_time++;
				
				if((!(LPC_GPIO0->FIOPIN & INDEX_PROX1)) )
				{
					delay_ms(100);
					if((!(LPC_GPIO0->FIOPIN & INDEX_PROX1)) )
					{
						//delay_ms(2000);
						I2CWriteLength[PORT_USED] = 3;
						I2CReadLength[PORT_USED] = 0;
						I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
						I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
						I2CMasterBuffer[PORT_USED][2] = 0x00;
						I2CEngine( PORT_USED );	
						delay_ms(100);					
						//delay_ms(10);
						delay_time=0;						
									
						break;
					}
				}
				else if(delay_time>80000000)	  //check the time
				{			 
					return 1;
				}
			}	
		}
		
	port_value |= 0X40;
	//port_value |= 0X20;

	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
	I2CMasterBuffer[PORT_USED][2] = port_value;
	I2CEngine( PORT_USED );	
	delay_ms(100);	
	
	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x0A;		/* address */
	I2CMasterBuffer[PORT_USED][2] = 0X02;
	I2CEngine( PORT_USED );	
				 		
	delay_ms(100);

	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x0A;		/* address */
	I2CMasterBuffer[PORT_USED][2] = 0X00;
	I2CEngine( PORT_USED );	
	delay_ms(100);   

	return 0;
}

unsigned int System_process4(void)
{
	unsigned int flag1,flag2,helmet1_flag;
	unsigned int delay_time;
	unsigned char port_value=0x00;
	
	
	helmet1_flag=0;

	
	if(System_status() == 1)
	{
		return 1;
	}

	port_value |= 0x40;
	port_value |= 0X20;

	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
	I2CMasterBuffer[PORT_USED][2] = port_value;
	I2CEngine( PORT_USED );	

	delay_ms(250);

		if((!(LPC_GPIO0->FIOPIN & INDEX_PROX2)))
		{
			//HELMET1 ON
			//port_value|= 0x02;
			port_value|= 0x01;
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
			I2CMasterBuffer[PORT_USED][2] = port_value;
			I2CEngine( PORT_USED );	
			delay_ms(100);

			helmet1_flag=1;
		}								  
		else if((!(LPC_GPIO0->FIOPIN & INDEX_PROX1)))
		{
			//HELMET2 ON

			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x0A;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0X04;
			I2CEngine( PORT_USED );	
			delay_ms(100); 

		}

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x48;
		I2CEngine( PORT_USED );	
		delay_ms(500);

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x00;
		I2CEngine( PORT_USED );	
		delay_ms(100);

		//SAVE THE nozel position
		I2CWriteLength[PORT_USED] = 4;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = 0XA0;
		I2CMasterBuffer[PORT_USED][1] = 0x00;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x01;		/* address */
		I2CMasterBuffer[PORT_USED][3] = 0x01;		/* Data0 */

	   	port_value |= 0X08;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );		
	
		delay_ms(3000);	 //ANGLE CHANGED 3500
		
		
		//ON THE PAINT 
		port_value ^= 0X08;
		port_value |= 0x10;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value; 
		I2CEngine( PORT_USED );	
		
		delay_ms(2000);	

		port_value |= 0X08;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );	
		delay_ms(3000);

		//ON THE PAINT 
		port_value ^= 0X08;
	//	port_value |= 0x10;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value; 
		I2CEngine( PORT_USED );	
		
		delay_ms(2000);	


		port_value |= 0X04;
		port_value ^= 0X20;
		port_value ^= 0X10;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );		
	
		delay_ms(2000);	
		

   		delay_time=0;

   		while(1)
		{
			delay_time++;
			if(delay_time > 40000000)	  //check the time
			{			 
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );
				delay_ms(100);
						
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );		
				delay_ms(100);

				return 1;
			}	 			
			else if((!(LPC_GPIO3->FIOPIN & NOZEL_HOME)) )
			{
				delay_ms(100);	
				if((!(LPC_GPIO3->FIOPIN & NOZEL_HOME)) )
				{
				   	//NOZEL MOTOR OFF
					port_value ^= 0X04;
					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
					I2CMasterBuffer[PORT_USED][2] = port_value;
					I2CEngine( PORT_USED );							
					delay_ms(500);
					break;
				}
			}				
		}

	   	//SAVE THE nozel position
		I2CWriteLength[PORT_USED] = 4;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = 0XA0;
		I2CMasterBuffer[PORT_USED][1] = 0x00;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x01;		/* address */
		I2CMasterBuffer[PORT_USED][3] = 0x00;		/* Data0 */
	
		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x48;
		I2CEngine( PORT_USED );
		delay_ms(100);
				
		//NOZEL MOTOR ON
		port_value |= 0x04;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );	
		delay_ms(100);
		//delay_ms(1500);

		

		delay_time=0;

   		while(1)
		{
			delay_time++;
			
			if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX2))  )
			{
				delay_ms(100);
				if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX2)))
				{
					//port_value ^= 0x04;
					port_value |= 0x10;

					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
					I2CMasterBuffer[PORT_USED][2] = port_value;
					I2CEngine( PORT_USED );						
					delay_ms(100); 	
					break;
				}			
			}			
			else if(delay_time > 30000000)	  
			{	
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay(100);

				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay(100);		 
				
				return 1;
			}
		}
	

	   delay_time=0;
	   flag1=0;
		flag2=0;

   		while(1)
		{
			delay_time++;
			
			if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX3))  )
			{
				delay_ms(100);
				if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX3)))
				{
					
					break;
				}			
			}			
			else if(delay_time>50000000)	  
			{	
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay_ms(100);

				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );
				delay_ms(100);			 
				
				return 1;
			}
		}

			
		//NOZEL MOTOR OFF
		port_value ^= 0x04;
		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );	
		delay_ms(100);

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x42;
		I2CEngine( PORT_USED );
			delay_ms(100);	
				
	   delay_time=0;
	   
   		while(1)
		{
			delay_time++;
			
			if((!(LPC_GPIO1->FIOPIN & ARM_UPPER_PROX2))  )
			{
				delay_ms(100);
				if((!(LPC_GPIO1->FIOPIN & ARM_UPPER_PROX2)))
				{
					
					break;
				}			
			}			
			else if(delay_time>80000000)	  
			{	
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );
					delay_ms(100);	

				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
					delay_ms(100);		 
				
				return 1;
			}
		} 			

//		//NOZEL MOTOR ON
		port_value |= 0X04;
		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );
			delay_ms(100);	

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x48;
		I2CEngine( PORT_USED );	
			delay_ms(100);


		//delay_ms(3000);	

		//ARM CYLINDER ON		
		port_value |= 0X20;
		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );	
			delay_ms(100);
		delay_time=0;
		flag1=0;
		

   		while(1)
		{
			delay_time++;
			
			if((!(LPC_GPIO0->FIOPIN & ARM_UPPER_PROX1)) && (flag1 == 0) )
			{
				delay_ms(100);
				if((!(LPC_GPIO0->FIOPIN & ARM_UPPER_PROX1)) && (flag1 == 0) )
				{
					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
					I2CMasterBuffer[PORT_USED][2] = 0x00;
					I2CEngine( PORT_USED );	
					flag1=1;
					delay_ms(100); 	
				}			
			}
			if((!(LPC_GPIO1->FIOPIN & NOZEL_INDEX)) && (flag2 == 0 ))
			{
				delay_ms(100);
				if((!(LPC_GPIO1->FIOPIN & NOZEL_INDEX)) && (flag2 == 0 ))
				{
					port_value ^= 0x04;

					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
					I2CMasterBuffer[PORT_USED][2] = port_value;
					I2CEngine( PORT_USED );		
					flag2=1;
					delay_ms(100);
				}				
			}
			if((flag1 == 1) && (flag2 == 1))
			{
			   	
				delay_ms(1000);	   //10000
				//LPC_GPIO2->FIOCLR 	 = 	SOLONID_SIGNAL;
				break;
			}
			if(delay_time>40000000)	  //check the time
			{	
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay_ms(100);

				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );
				delay_ms(100);			 
				
				return 1;
			}
		}

		//TOTAL TIME TO GO DOWN IS  SEC
		//delay_ms(500);

		//ARM CYLINDER OFF

		port_value ^= 0X20;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );		
		delay_ms(100);


		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x88;
		I2CEngine( PORT_USED );	
		delay_ms(100);	

	   
		//NOZEL MOTOR ON RVS
		port_value |= 0X08;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );		
			delay_ms(100);	

		delay_time=0;

   		while(1)
		{
			delay_time++;
			
			if((!(LPC_GPIO1->FIOPIN & ARM_UPPER_PROX2))  )
			{
				delay_ms(100);
				if((!(LPC_GPIO1->FIOPIN & ARM_UPPER_PROX2)))
				{
					
					break;
				}			
			}			
			else if(delay_time>40000000)	  
			{	
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );
					delay_ms(100);	

				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
					delay_ms(100);		 
				
				return 1;
			}
		}


		//NOZEL MOTOR OFF RVS
		port_value ^= 0X08;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );		
	
		delay_ms(100);

		delay_time=0;

   		while(1)
		{
			delay_time++;
			
			if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX3))  )
			{
				delay_ms(100);
				if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX3)))
				{
					
					break;
				}			
			}				
			else if(delay_time>30000000)	  
			{	
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay_ms(100);

				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay_ms(100);		 
				
				return 1;
			}
		}


		//NOZEL MOTOR ON RVS
		port_value |= 0X08;
	//	port_value ^= 0X10;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );	

		delay_ms(100);

			delay_time=0;

   		while(1)
		{
			delay_time++;
			
			if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX2))  )
			{
				delay_ms(100);
				if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX2)))
				{
					
					break;
				}			
			}				
			else if(delay_time>30000000)	  
			{	
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay_ms(100);

				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );			 
				delay_ms(100);
				
				return 1;
			}
		}

		port_value ^= 0X10;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );	

		delay_ms(100);

	
		flag1=0;
		flag2=0;
   		delay_time=0;

   		while(1)
		{
			delay_time++;
			if(delay_time>40000000)	  //check the time
			{			 
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );
					delay_ms(100);
						
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
					delay_ms(100);	

				return 1;
			}
			if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX1)) && (flag1 == 0 ))
			{
				delay_ms(100);
				if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX1)) && (flag1 == 0 ))
				{
					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
					I2CMasterBuffer[PORT_USED][2] = 0x00;
					I2CEngine( PORT_USED );
						delay_ms(100);		
					
					//ELECTROMAGNET OFF
					port_value ^=0X40;

					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
					I2CMasterBuffer[PORT_USED][2] = port_value;
					I2CEngine( PORT_USED );		
					flag1=1;
					delay_ms(100);
				}
	
			}
			if((!(LPC_GPIO3->FIOPIN & NOZEL_HOME)) && (flag2 == 0 ))
			{
				delay_ms(100);	
				if((!(LPC_GPIO3->FIOPIN & NOZEL_HOME)) && (flag2 == 0 ))
				{
				   	//NOZEL MOTOR OFF
					port_value ^= 0X08;
					//port_value ^= 0X10;
					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
					I2CMasterBuffer[PORT_USED][2] = port_value;
					I2CEngine( PORT_USED );		
					flag2=1;
					delay_ms(100);
				}
			}		
			if((flag1 == 1) && (flag2 == 1))
			{
				
				
				//delay_ms(500);
				break;
			}
		}

		if(helmet1_flag == 1)
		{
		    port_value ^= 0X01;
		}
		else
		{
			
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x0A;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0X00;
			I2CEngine( PORT_USED );	
				delay_ms(100);
		}

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );		

		delay_ms(500);

		if((!(LPC_GPIO0->FIOPIN & INDEX_PROX1)))
		{
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0x14;
			I2CEngine( PORT_USED );

			delay_ms(4000);
			
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0x11;
			I2CEngine( PORT_USED );
			delay_ms(100);

			delay_time=0;
			while(1)
			{
				delay_time++;
				
				if((!(LPC_GPIO0->FIOPIN & INDEX_PROX2)) )
				{
					delay_ms(100);
					if((!(LPC_GPIO0->FIOPIN & INDEX_PROX2)) )
					{
						//delay_ms(2000);
						I2CWriteLength[PORT_USED] = 3;
						I2CReadLength[PORT_USED] = 0;
						I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
						I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
						I2CMasterBuffer[PORT_USED][2] = 0x00;
						I2CEngine( PORT_USED );
						delay_ms(100);
						delay_time=0;
						//delay_ms(10);	 					
						
						break;
					}					
				}
				else if(delay_time>80000000)	  //check the time
				{			 
					return 1;
				}
			}
		}
		else if((!(LPC_GPIO0->FIOPIN & INDEX_PROX2)))
		{
			
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0x24;
			I2CEngine( PORT_USED );

			delay_ms(4000);
			
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0x21;
			I2CEngine( PORT_USED );
			delay_ms(100);

			delay_time=0;
			while(1)
			{
				delay_time++;
				
				if((!(LPC_GPIO0->FIOPIN & INDEX_PROX1)) )
				{
					delay_ms(100);
					if((!(LPC_GPIO0->FIOPIN & INDEX_PROX1)) )
					{
						//delay_ms(2000);
						I2CWriteLength[PORT_USED] = 3;
						I2CReadLength[PORT_USED] = 0;
						I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
						I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
						I2CMasterBuffer[PORT_USED][2] = 0x00;
						I2CEngine( PORT_USED );
						delay_ms(100);						
						//delay_ms(10);
						delay_time=0;						
									
						break;
					}
				}
				else if(delay_time>80000000)	  //check the time
				{			 
					return 1;
				}
			}	
		}
		
	port_value |= 0X40;
	port_value |= 0X20;

	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
	I2CMasterBuffer[PORT_USED][2] = port_value;
	I2CEngine( PORT_USED );	
	delay_ms(100);	
	
	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x0A;		/* address */
	I2CMasterBuffer[PORT_USED][2] = 0X02;
	I2CEngine( PORT_USED );	
				 		
	delay_ms(100);

	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x0A;		/* address */
	I2CMasterBuffer[PORT_USED][2] = 0X00;
	I2CEngine( PORT_USED );	  
	delay_ms(100); 


	return 0;

}

unsigned int System_process5(void)
{
	unsigned int flag1,flag2,helmet1_flag;
	unsigned int delay_time;
	unsigned char port_value=0x00;
	
	
	helmet1_flag=0;

	
	if(System_status() == 1)
	{
		return 1;
	}

		//ELECTROMAGNET ON

	port_value |= 0x40;
	//port_value |= 0X20;

	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
	I2CMasterBuffer[PORT_USED][2] = port_value;
	I2CEngine( PORT_USED );	

	delay_ms(250);

		if((!(LPC_GPIO0->FIOPIN & INDEX_PROX2)))
		{
			//HELMET1 ON
			//port_value|= 0x02;
			port_value|= 0x01;
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
			I2CMasterBuffer[PORT_USED][2] = port_value;
			I2CEngine( PORT_USED );	
			delay_ms(100);

			helmet1_flag=1;
		}								  
		else if((!(LPC_GPIO0->FIOPIN & INDEX_PROX1)))
		{
			//HELMET2 ON

			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x0A;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0X04;
			I2CEngine( PORT_USED );	
			delay_ms(100);


		}

		delay_ms(500);
	  

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x48;
		I2CEngine( PORT_USED );
		delay_ms(100);	
	  	  
		flag1=0;
		flag2=0;
//	
//		I2CWriteLength[PORT_USED] = 3;
//		I2CReadLength[PORT_USED] = 0;
//		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
//		I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
//		I2CMasterBuffer[PORT_USED][2] = 0x42;
//		I2CEngine( PORT_USED );	
//		delay_ms(100);
		
		port_value |= 0x04;
		//port_value |= 0x20;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );	

		delay_ms(100);

	   	delay_time=0;

   		while(1)
		{
			delay_time++;
			if(delay_time > 100000000)	  //check the time
			{			 
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );
				delay_ms(100);
						
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );		
				delay_ms(100);

				return 1;
			}	 			
			else if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX2)) )
			{
				delay_ms(100);	
				if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX2)) )
				{
				   
					port_value ^= 0x04;
					port_value |= 0x10;

					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
					I2CMasterBuffer[PORT_USED][2] = port_value;
					I2CEngine( PORT_USED );						
					delay_ms(100); 	
					break;
				}
			}				
		}

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x42;
		I2CEngine( PORT_USED );	
		delay_ms(100);

		delay_time=0;
	  
   		while(1)
		{
			delay_time++;
			
			if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX3))  )
			{
				delay_ms(100);
				if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX3)))
				{
					
					break;
				}			
			}			
			else if(delay_time>120000000)	  
			{	
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay_ms(100);

				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay_ms(100);		 
				
				return 1;
			}
		}
	
		//NOZEL MOTOR ON
		port_value |= 0x04;
		//port_value |= 0x20;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );	
		
		delay_ms(2500);		 //3s
			
		//NOZEL MOTOR OFF
		port_value ^= 0x04;
			
		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );	 
		delay_ms(100);	

		delay_time=0;

   		while(1)
		{
			delay_time++;
			if(delay_time > 100000000)	  //check the time
			{			 
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );
				delay_ms(100);
						
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );		
				delay_ms(100);

				return 1;
			}	 			
			else if((!(LPC_GPIO1->FIOPIN & ARM_UPPER_PROX2)) )
			{
				delay_ms(100);	
				if((!(LPC_GPIO1->FIOPIN & ARM_UPPER_PROX2)) )
				{
				   
					break;
				}
			}				
		} 

		 	I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x48;
		I2CEngine( PORT_USED );	
		delay_ms(100);

//		//NOZEL MOTOR ON
		port_value |= 0X04;
		port_value |= 0X20;
		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );	
		delay_ms(100);

					      
	  	
		flag1=0;
		flag2=0;
		delay_time=0;

   		while(1)
		{
			delay_time++;

			if(delay_time>40000000)	  //check the time
			{	
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay_ms(100);

				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay_ms(100);		 
				
				return 1;
			}
			
			if((!(LPC_GPIO0->FIOPIN & ARM_UPPER_PROX1)) && (flag1 == 0) )
			{
				delay_ms(100);
				if((!(LPC_GPIO0->FIOPIN & ARM_UPPER_PROX1)) && (flag1 == 0) )
				{
					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
					I2CMasterBuffer[PORT_USED][2] = 0x00;
					I2CEngine( PORT_USED );	
					flag1=1;
					delay_ms(100); 	
					//break;
				}			
			}
			if((!(LPC_GPIO1->FIOPIN & NOZEL_INDEX)) && (flag2 == 0 ))
			{
				delay_ms(100);
				if((!(LPC_GPIO1->FIOPIN & NOZEL_INDEX)) && (flag2 == 0 ))
				{
					port_value ^= 0x04;

					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
					I2CMasterBuffer[PORT_USED][2] = port_value;
					I2CEngine( PORT_USED );	
					delay(100);	
					flag2=1;
					
				}				
			}
			if((flag1 == 1) && (flag2 == 1))
			{
			   	
				delay_ms(2000);	   
				break;
			}
			
		}
				
//		port_value |= 0X04;
//
//		I2CWriteLength[PORT_USED] = 3;
//		I2CReadLength[PORT_USED] = 0;
//		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
//		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
//		I2CMasterBuffer[PORT_USED][2] = port_value;
//		I2CEngine( PORT_USED );
//		delay_ms(100);
//
//		delay_time=0;
//		flag2=0;
//   		while(1)
//		{
//			delay_time++;
//
//			if((!(LPC_GPIO1->FIOPIN & NOZEL_INDEX)) && (flag2 == 0 ))
//			{
//				delay_ms(100);
//				if((!(LPC_GPIO1->FIOPIN & NOZEL_INDEX)) && (flag2 == 0 ))
//				{
//					port_value ^= 0x04;
//
//					I2CWriteLength[PORT_USED] = 3;
//					I2CReadLength[PORT_USED] = 0;
//					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
//					I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
//					I2CMasterBuffer[PORT_USED][2] = port_value;
//					I2CEngine( PORT_USED );	
//					delay_ms(100);	
//					flag2=1;
//					//delay_ms(500);
//					break;
//				}				
//			}
//			else if(delay_time>40000000)	  //check the time
//			{	
//				I2CWriteLength[PORT_USED] = 3;
//				I2CReadLength[PORT_USED] = 0;
//				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
//				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
//				I2CMasterBuffer[PORT_USED][2] = 0x00;
//				I2CEngine( PORT_USED );	
//				delay_ms(100);
//
//				I2CWriteLength[PORT_USED] = 3;
//				I2CReadLength[PORT_USED] = 0;
//				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
//				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
//				I2CMasterBuffer[PORT_USED][2] = 0x00;
//				I2CEngine( PORT_USED );	
//				delay_ms(100);		 
//				
//				return 1;
//			}
//		}
		
		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x88;
		I2CEngine( PORT_USED );		  
		delay_ms(100);  

//		delay_time=0;
//
//   		while(1)
//		{
//			delay_time++;
//			if(delay_time > 40000000)	  //check the time
//			{			 
//				I2CWriteLength[PORT_USED] = 3;
//				I2CReadLength[PORT_USED] = 0;
//				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
//				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
//				I2CMasterBuffer[PORT_USED][2] = 0x00;
//				I2CEngine( PORT_USED );
//				delay_ms(100);
//						
//				I2CWriteLength[PORT_USED] = 3;
//				I2CReadLength[PORT_USED] = 0;
//				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
//				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
//				I2CMasterBuffer[PORT_USED][2] = 0x00;
//				I2CEngine( PORT_USED );		
//				delay_ms(100);
//
//				return 1;
//			}	 			
//			else if((!(LPC_GPIO1->FIOPIN & ARM_UPPER_PROX2)) )
//			{
//				delay_ms(100);	
//				if((!(LPC_GPIO1->FIOPIN & ARM_UPPER_PROX2)) )
//				{
//				   
//					break;
//				}
//			}				
//		}
//
//			//NOZEL MOTOR ON RVS
//		port_value |= 0X08;	
//
//		I2CWriteLength[PORT_USED] = 3;
//		I2CReadLength[PORT_USED] = 0;
//		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
//		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
//		I2CMasterBuffer[PORT_USED][2] = port_value;
//		I2CEngine( PORT_USED );	
//		
//		delay_ms(2000);
//
//		port_value ^= 0X08;	
//
//		I2CWriteLength[PORT_USED] = 3;
//		I2CReadLength[PORT_USED] = 0;
//		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
//		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
//		I2CMasterBuffer[PORT_USED][2] = port_value;
//		I2CEngine( PORT_USED );	
//	
//		delay_ms(100);

	
		delay_time=0;

   		while(1)
		{
			delay_time++;
			if(delay_time > 40000000)	  //check the time
			{			 
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );
				delay_ms(100);
						
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );		
				delay_ms(100);

				return 1;
			}	 			
			else if((!(LPC_GPIO1->FIOPIN & ARM_UPPER_PROX2)) )
			{
				delay_ms(100);	
				if((!(LPC_GPIO1->FIOPIN & ARM_UPPER_PROX2)) )
				{
				   	delay_ms(2000);
					break;
				}
			}				
		}

		port_value |= 0X08;
	   	
		port_value ^= 0X20;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );	
	
		delay_ms(100);

		flag1=0;
		flag2=0;
   		delay_time=0;

   		while(1)
		{
			delay_time++;
			if(delay_time>40000000)	  //check the time
			{			 
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );
				delay_ms(100);
						
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay_ms(100);	

				return 1;
			}
			if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX1)) && (flag1 == 0 ))
			{
				delay_ms(100);
				if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX1)) && (flag1 == 0 ))
				{
					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
					I2CMasterBuffer[PORT_USED][2] = 0x00;
					I2CEngine( PORT_USED );					
					delay_ms(100);
					flag1=1;
				}
	
			}
			if((!(LPC_GPIO3->FIOPIN & NOZEL_HOME)) && (flag2 == 0 ))
			{
				delay_ms(100);	
				if((!(LPC_GPIO3->FIOPIN & NOZEL_HOME)) && (flag2 == 0 ))
				{
				   	//NOZEL MOTOR OFF
					port_value ^= 0X08;
					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
					I2CMasterBuffer[PORT_USED][2] = port_value;
					I2CEngine( PORT_USED );		
					flag2=1;
					delay_ms(100);
				}
			}		
			if((flag1 == 1) && (flag2 == 1))
			{
				delay_ms(100);
				break;
			}
		}

		//SAVE THE nozel position
		I2CWriteLength[PORT_USED] = 4;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = 0XA0;
		I2CMasterBuffer[PORT_USED][1] = 0x00;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x01;		/* address */
		I2CMasterBuffer[PORT_USED][3] = 0x01;		/* Data0 */
	
			
		I2CEngine( PORT_USED );
		delay_ms(250);

		port_value |= 0X08;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );		
	
		delay_ms(1000);	 //ANGLE CHANGED 1500
		
		
		//ON THE PAINT 
		port_value ^= 0X08;
		port_value |= 0x10;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value; 
		I2CEngine( PORT_USED );	
		
		delay_ms(1000);	

//		//OFF THE PAINT 
//		port_value ^= 0x10;
//
//		I2CWriteLength[PORT_USED] = 3;
//		I2CReadLength[PORT_USED] = 0;
//		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
//		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
//		I2CMasterBuffer[PORT_USED][2] = port_value; 
//		I2CEngine( PORT_USED );	
//		delay_ms(1000);


		port_value |= 0X04;
		port_value ^= 0X10;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );		
	
		delay_ms(500);	
		
   		delay_time=0;

   		while(1)
		{
			delay_time++;
			if(delay_time>40000000)	  //check the time
			{			 
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );
				delay_ms(100);
						
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );
				delay_ms(100);		

				return 1;
			}	 			
			else if((!(LPC_GPIO3->FIOPIN & NOZEL_HOME)) )
			{
				delay_ms(100);	
				if((!(LPC_GPIO3->FIOPIN & NOZEL_HOME)) )
				{
				   	//NOZEL MOTOR OFF
					port_value ^= 0X04;
					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
					I2CMasterBuffer[PORT_USED][2] = port_value;
					I2CEngine( PORT_USED );							
					delay_ms(500);
					break;
				}
			}				
		}

		//SAVE THE nozel position
		I2CWriteLength[PORT_USED] = 4;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = 0XA0;
		I2CMasterBuffer[PORT_USED][1] = 0x00;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x01;		/* address */
		I2CMasterBuffer[PORT_USED][3] = 0x00;		/* Data0 */
	
			
		I2CEngine( PORT_USED );
		delay_ms(250);

//		//PAINT SOLONOID OFF
		

		//port_value ^= 0X10;
		port_value |= 0X04;

		if(helmet1_flag == 1)
		{
		    port_value ^= 0X01;
		}
		else
		{
			
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x0A;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0X00;
			I2CEngine( PORT_USED );
			delay_ms(100);	
		}

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );	
		delay_ms(100);	


		flag1=0;
		flag2=0;
   		delay_time=0;

   		while(1)
		{
			delay_time++;
			if(delay_time>40000000)	  //check the time
			{			 
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );
				delay_ms(100);
						
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay_ms(100);	

				return 1;
			}
			
			if((!(LPC_GPIO3->FIOPIN & NOZEL_HOME)) && (flag2 == 0 ))
			{
				delay_ms(100);	
				if((!(LPC_GPIO3->FIOPIN & NOZEL_HOME)) && (flag2 == 0 ))
				{
				   	//NOZEL MOTOR OFF
					port_value ^= 0X08;
					port_value ^=0X40;
	
					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
					I2CMasterBuffer[PORT_USED][2] = port_value;
					I2CEngine( PORT_USED );		
					flag2=1;
					delay_ms(100);
					break;
				}
			}		
			
		}


		delay_ms(200);

		if((!(LPC_GPIO0->FIOPIN & INDEX_PROX1)))
		{
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0x14;
			I2CEngine( PORT_USED );

			delay_ms(4000);
			
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0x11;
			I2CEngine( PORT_USED );
			delay_ms(100);

			delay_time=0;
			while(1)
			{
				delay_time++;
														   
				if((!(LPC_GPIO0->FIOPIN & INDEX_PROX2)) )
				{
					delay_ms(100);
					if((!(LPC_GPIO0->FIOPIN & INDEX_PROX2)) )
					{
						//delay_ms(2000);
						I2CWriteLength[PORT_USED] = 3;
						I2CReadLength[PORT_USED] = 0;
						I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
						I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
						I2CMasterBuffer[PORT_USED][2] = 0x00;
						I2CEngine( PORT_USED );
						delay_ms(100);
						delay_time=0;						
						break;
					}					
				}
				else if(delay_time>80000000)	  //check the time
				{			 
					return 1;
				}
			}
		}
		else if((!(LPC_GPIO0->FIOPIN & INDEX_PROX2)))
		{
			
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0x24;
			I2CEngine( PORT_USED );

			delay_ms(4000);
			
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0x21;
			I2CEngine( PORT_USED );
			delay_ms(100);

			delay_time=0;
			while(1)
			{
				delay_time++;
				
				if((!(LPC_GPIO0->FIOPIN & INDEX_PROX1)) )
				{
					delay_ms(100);
					if((!(LPC_GPIO0->FIOPIN & INDEX_PROX1)) )
					{
						//delay_ms(2000);
						I2CWriteLength[PORT_USED] = 3;
						I2CReadLength[PORT_USED] = 0;
						I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
						I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
						I2CMasterBuffer[PORT_USED][2] = 0x00;
						I2CEngine( PORT_USED );	
						delay_ms(100);					
						//delay_ms(10);
						delay_time=0;						
									
						break;
					}
				}
				else if(delay_time>80000000)	  //check the time
				{			 
					return 1;
				}
			}	
		}
		
	port_value |= 0X40;
	//port_value |= 0X20;

	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
	I2CMasterBuffer[PORT_USED][2] = port_value;
	I2CEngine( PORT_USED );	
	delay_ms(100);	
	
	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x0A;		/* address */
	I2CMasterBuffer[PORT_USED][2] = 0X02;
	I2CEngine( PORT_USED );	
				 		
	delay_ms(100);

	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x0A;		/* address */
	I2CMasterBuffer[PORT_USED][2] = 0X00;
	I2CEngine( PORT_USED );	 
	delay_ms(100);  

	return 0;
}


unsigned int System_process6(void)
{
	unsigned int flag1,flag2,helmet1_flag;
	unsigned int delay_time;
	unsigned char port_value=0x00;
	
	
	helmet1_flag=0;

	
	if(System_status() == 1)
	{
		return 1;
	}

	//ELECTROMAGNET ON

	port_value|= 0x40;

	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
	I2CMasterBuffer[PORT_USED][2] = port_value;
	I2CEngine( PORT_USED );	

	delay_ms(250);

		if((!(LPC_GPIO0->FIOPIN & INDEX_PROX2)))
		{
			//HELMET1 ON
			//port_value|= 0x02;
			port_value|= 0x01;
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
			I2CMasterBuffer[PORT_USED][2] = port_value;
			I2CEngine( PORT_USED );	
			delay_ms(100);

			helmet1_flag=1;
		}								  
		else if((!(LPC_GPIO0->FIOPIN & INDEX_PROX1)))
		{
			//HELMET2 ON

			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x0A;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0X04;
			I2CEngine( PORT_USED );	
			delay_ms(100); 
		}  	   	
		
		//ON THE PAINT 
		port_value|= 0x10;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value; 
		I2CEngine( PORT_USED );	
		delay_ms(1000);	 

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x48;
		I2CEngine( PORT_USED );	
		delay_ms(100);
		

		flag1=0;
		flag2=0;
		delay_ms(250);

		//NOZEL MOTOR ON
		port_value|= 0x04;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );											  
	
		delay_ms(2000);		 //DELAY TO MOVE THE NOZEL MOTOR TO HORIZONTAL
		
			
		//NOZEL MOTOR OFF
		port_value ^= 0x04;
		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );	

		delay_ms(4000);  	 //DELAY TO KEEP THE NOZEL MOTOR IN HORIZONTAL POSITION FOR SOME TIME

//		//NOZEL MOTOR ON
		port_value |= 0X04;
		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );	

		delay_ms(2000);	

		//ARM CYLINDER ON		
		port_value |= 0X20;
		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );	
		delay_ms(100);

		delay_time=0;

   		while(1)
		{
			delay_time++;
			
			if((!(LPC_GPIO0->FIOPIN & ARM_UPPER_PROX1)) && (flag1 == 0) )
			{
				delay_ms(100);
				if((!(LPC_GPIO0->FIOPIN & ARM_UPPER_PROX1)) && (flag1 == 0) )
				{
					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
					I2CMasterBuffer[PORT_USED][2] = 0x00;
					I2CEngine( PORT_USED );	
					flag1=1;
					delay_ms(100); 	
				}			
			}
			if((!(LPC_GPIO1->FIOPIN & NOZEL_INDEX)) && (flag2 == 0 ))
			{
				delay_ms(100);
				if((!(LPC_GPIO1->FIOPIN & NOZEL_INDEX)) && (flag2 == 0 ))
				{
					port_value ^= 0x04;

					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
					I2CMasterBuffer[PORT_USED][2] = port_value;
					I2CEngine( PORT_USED );		
					flag2=1;
					delay_ms(100);
				}				
			}
			if((flag1 == 1) && (flag2 == 1))
			{
			   	
				delay_ms(150);	   
				break;
			}
			if(delay_time>40000000)	  
			{	
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay_ms(100);

				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay_ms(100);		 
				
				return 1;
			}
		}

		
		//ARM CYLINDER OFF

		port_value ^= 0X20;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );		
		delay_ms(200);

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x88;
		I2CEngine( PORT_USED );		

	   
		delay_ms(2000);   //DELAY TO MOVE THE ARM WITHOUT CHANGING THE NOZEL

		//NOZEL MOTOR ON RVS
		port_value |= 0X08;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );		
	
		delay_ms(2000);		  //SIMPLE DELAY
		
	
		flag1=0;
		flag2=0;
   		delay_time=0;

   		while(1)
		{
			delay_time++;
			if(delay_time>40000000)	  //check the time
			{			 
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );
				delay_ms(100);
						
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay_ms(100);	

				return 1;
			}
			if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX1)) && (flag1 == 0 ))
			{
				delay_ms(100);
				if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX1)) && (flag1 == 0 ))
				{
					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
					I2CMasterBuffer[PORT_USED][2] = 0x00;
					I2CEngine( PORT_USED );	
					delay_ms(100);	
					
					//ELECTROMAGNET OFF
					port_value ^=0X40;

					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
					I2CMasterBuffer[PORT_USED][2] = port_value;
					I2CEngine( PORT_USED );		
					flag1=1;
					delay_ms(100);
				}
	
			}
			if((!(LPC_GPIO3->FIOPIN & NOZEL_HOME)) && (flag2 == 0 ))
			{
				delay_ms(100);	
				if((!(LPC_GPIO3->FIOPIN & NOZEL_HOME)) && (flag2 == 0 ))
				{
				   	//NOZEL MOTOR OFF
					port_value ^= 0X08;
					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
					I2CMasterBuffer[PORT_USED][2] = port_value;
					I2CEngine( PORT_USED );		
					flag2=1;
					delay_ms(100);
				}
			}		
			if((flag1 == 1) && (flag2 == 1))
			{					
				//delay_ms(500);
				break;
			}
		}

		//PAINT SOLONOID OFF
		port_value ^= 0X10;		

		if(helmet1_flag == 1)
		{
		    port_value ^= 0X01;
		}
		else
		{
			
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x0A;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0X00;
			I2CEngine( PORT_USED );	
			delay_ms(100);
		}

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );		

		delay_ms(500);

		if((!(LPC_GPIO0->FIOPIN & INDEX_PROX1)))
		{
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0x14;
			I2CEngine( PORT_USED );

			delay_ms(4000);
			
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0x11;
			I2CEngine( PORT_USED );
			delay_ms(100);

			delay_time=0;
			while(1)
			{
				delay_time++;
				
				if((!(LPC_GPIO0->FIOPIN & INDEX_PROX2)) )
				{
					delay_ms(100);
					if((!(LPC_GPIO0->FIOPIN & INDEX_PROX2)) )
					{
						//delay_ms(2000);
						I2CWriteLength[PORT_USED] = 3;
						I2CReadLength[PORT_USED] = 0;
						I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
						I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
						I2CMasterBuffer[PORT_USED][2] = 0x00;
						I2CEngine( PORT_USED );
						delay_ms(100);

						delay_time=0;						
						break;
					}					
				}
				else if(delay_time>80000000)	  //check the time
				{			 
					return 1;
				}
			}
		}
		else if((!(LPC_GPIO0->FIOPIN & INDEX_PROX2)))
		{
			
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0x24;
			I2CEngine( PORT_USED );

			delay_ms(4000);
			
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0x21;
			I2CEngine( PORT_USED );
			delay_ms(100);

			delay_time=0;
			while(1)
			{
				delay_time++;
				
				if((!(LPC_GPIO0->FIOPIN & INDEX_PROX1)) )
				{
					delay_ms(100);
					if((!(LPC_GPIO0->FIOPIN & INDEX_PROX1)) )
					{
						//delay_ms(2000);
						I2CWriteLength[PORT_USED] = 3;
						I2CReadLength[PORT_USED] = 0;
						I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
						I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
						I2CMasterBuffer[PORT_USED][2] = 0x00;
						I2CEngine( PORT_USED );	
						delay_ms(100);					
						//delay_ms(10);
						delay_time=0;						
									
						break;
					}
				}
				else if(delay_time>80000000)	  //check the time
				{			 
					return 1;
				}
			}	
		}
		
	port_value |= 0X40;
	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
	I2CMasterBuffer[PORT_USED][2] = port_value;
	I2CEngine( PORT_USED );	
	delay_ms(100);
	
	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x0A;		/* address */
	I2CMasterBuffer[PORT_USED][2] = 0X02;
	I2CEngine( PORT_USED );	
				 		
	delay_ms(100);

	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x0A;		/* address */
	I2CMasterBuffer[PORT_USED][2] = 0X00;
	I2CEngine( PORT_USED );	
	delay_ms(100);

	return 0;

}

unsigned int System_process7(void) //BUDS OPEN FACE
{
	unsigned int flag1,flag2,helmet1_flag;
	unsigned int delay_time;
	unsigned char port_value=0x00;
	
	
	helmet1_flag=0;

	
	if(System_status() == 1)
	{
		return 1;
	}

	port_value |= 0x40;
	port_value |= 0X20;

	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
	I2CMasterBuffer[PORT_USED][2] = port_value;
	I2CEngine( PORT_USED );	

	delay_ms(250);

		if((!(LPC_GPIO0->FIOPIN & INDEX_PROX2)))
		{
			//HELMET1 ON
			//port_value|= 0x02;
			port_value|= 0x01;
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
			I2CMasterBuffer[PORT_USED][2] = port_value;
			I2CEngine( PORT_USED );	
			delay_ms(100);

			helmet1_flag=1;
		}								  
		else if((!(LPC_GPIO0->FIOPIN & INDEX_PROX1)))
		{
			//HELMET2 ON

			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x0A;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0X04;
			I2CEngine( PORT_USED );	 
			delay_ms(100);

		}

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x48;
		I2CEngine( PORT_USED );	
		delay_ms(500);

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x00;
		I2CEngine( PORT_USED );	
		delay_ms(100);

		//SAVE THE nozel position
		I2CWriteLength[PORT_USED] = 4;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = 0XA0;
		I2CMasterBuffer[PORT_USED][1] = 0x00;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x01;		/* address */
		I2CMasterBuffer[PORT_USED][3] = 0x01;		/* Data0 */	 	
			
		I2CEngine( PORT_USED );
		delay_ms(250);

	   	port_value |= 0X08;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );		
	
		delay_ms(3500);	 //ANGLE CHANGED 1500
		
		
		//ON THE PAINT 
		port_value ^= 0X08;
		port_value |= 0x10;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value; 
		I2CEngine( PORT_USED );	
		
		delay_ms(4000);	


		port_value |= 0X04;
		port_value ^= 0X20;
		port_value ^= 0x10;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );		
	
		delay_ms(2500);	
		
   		delay_time=0;

   		while(1)
		{
			delay_time++;
			if(delay_time>40000000)	  //check the time
			{			 
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );
				delay_ms(100);
						
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay_ms(100);	

				return 1;
			}	 			
			else if((!(LPC_GPIO3->FIOPIN & NOZEL_HOME)) )
			{
				delay_ms(100);	
				if((!(LPC_GPIO3->FIOPIN & NOZEL_HOME)) )
				{
				   	//NOZEL MOTOR OFF
					port_value ^= 0X04;
					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
					I2CMasterBuffer[PORT_USED][2] = port_value;
					I2CEngine( PORT_USED );							
					delay_ms(500);
					break;
				}
			}				
		}

	   	
		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x48;
		I2CEngine( PORT_USED );	

		delay_ms(100);

		//TOTAL TIME TO GO UP WITH SPEED CONTROL IS APPROX 10 TO 12 SEC

//		I2CWriteLength[PORT_USED] = 3;
//		I2CReadLength[PORT_USED] = 0;
//		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
//		I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
//		I2CMasterBuffer[PORT_USED][2] = 0x42;
//		I2CEngine( PORT_USED );	
//		delay_ms(100);

		flag1=0;
		flag2=0;
		

	
		//SAVE THE nozel position
		I2CWriteLength[PORT_USED] = 4;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = 0XA0;
		I2CMasterBuffer[PORT_USED][1] = 0x00;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x01;		/* address */
		I2CMasterBuffer[PORT_USED][3] = 0x00;		/* Data0 */
	
			
		I2CEngine( PORT_USED );
		delay_ms(250);
	

		//NOZEL MOTOR ON
		port_value |= 0x04;
		//port_value |= 0x10;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );	
		delay_ms(100);	 	
			
		//NOZEL MOTOR OFF
	

		delay_time=0;

   		while(1)
		{
			delay_time++;
			
			if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX2))  )
			{
				delay_ms(100);
				if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX2)))
				{
					port_value ^= 0x04;
					port_value |= 0x10;

					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
					I2CMasterBuffer[PORT_USED][2] = port_value;
					I2CEngine( PORT_USED );						
					delay_ms(100); 	
					break;
				}			
			}			
			else if(delay_time > 30000000)	  
			{	
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay(100);

				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay(100);		 
				
				return 1;
			}
		}

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x42;
		I2CEngine( PORT_USED );	
		delay_ms(100);
	   	
		delay_time=0;
	  
   		while(1)
		{
			delay_time++;
			
			if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX3))  )
			{
				delay_ms(100);
				if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX3)))
				{
					
					break;
				}			
			}			
			else if(delay_time>120000000)	  
			{	
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay_ms(100);

				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay_ms(100);		 
				
				return 1;
			}
		}
	

//		//NOZEL MOTOR ON
		port_value |= 0X04;
		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );	
		delay_ms(100);

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x48;
		I2CEngine( PORT_USED );	
		delay_ms(100);

		delay_time=0;
		flag1=0;
		flag2=0;
   		while(1)
		{
			delay_time++;
			if(delay_time>40000000)	  //check the time
			{	
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay_ms(100);

				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay_ms(100);		 
				
				return 1;
			}
			if((!(LPC_GPIO1->FIOPIN & ARM_UPPER_PROX2)) )
			{
				delay_ms(100);
				if((!(LPC_GPIO1->FIOPIN & ARM_UPPER_PROX2))  )
				{
					break;
				}			
			}
			
			if((!(LPC_GPIO1->FIOPIN & NOZEL_INDEX)) && (flag2 == 0 ))
			{
				delay_ms(100);
				if((!(LPC_GPIO1->FIOPIN & NOZEL_INDEX)) && (flag2 == 0 ))
				{
					port_value ^= 0x04;

					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
					I2CMasterBuffer[PORT_USED][2] = port_value;
					I2CEngine( PORT_USED );					
					delay_ms(100);
					flag2=1;
				}				
			}			
		}

		//ARM CYLINDER ON		
		port_value |= 0X20;
		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );
		delay_ms(100);
			
		delay_time=0;
		flag1=0;
   		while(1)
		{
			delay_time++;
			
			if((!(LPC_GPIO0->FIOPIN & ARM_UPPER_PROX1)) && (flag1 == 0) )
			{
				delay_ms(100);
				if((!(LPC_GPIO0->FIOPIN & ARM_UPPER_PROX1)) && (flag1 == 0) )
				{
					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
					I2CMasterBuffer[PORT_USED][2] = 0x00;
					I2CEngine( PORT_USED );	
					flag1=1;
					delay_ms(100); 	
				}			
			}
			if((!(LPC_GPIO1->FIOPIN & NOZEL_INDEX)) && (flag2 == 0 ))
			{
				delay_ms(100);
				if((!(LPC_GPIO1->FIOPIN & NOZEL_INDEX)) && (flag2 == 0 ))
				{
					port_value ^= 0x04;

					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
					I2CMasterBuffer[PORT_USED][2] = port_value;
					I2CEngine( PORT_USED );		
					flag2=1;
					delay_ms(100);
				}				
			}
			if((flag1 == 1) && (flag2 == 1))
			{
			   	
				delay_ms(500);	   //10000
				//LPC_GPIO2->FIOCLR 	 = 	SOLONID_SIGNAL;
				break;
			}
			if(delay_time>40000000)	  //check the time
			{	
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay_ms(100);

				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay_ms(100);		 
				
				return 1;
			}
		}	

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x88;
		I2CEngine( PORT_USED );		

	   	delay_ms(100);
	
		delay_time=0;
		
   		while(1)
		{
			delay_time++;
			
			if((!(LPC_GPIO1->FIOPIN & ARM_UPPER_PROX2)) )
			{
				delay_ms(100);
				if((!(LPC_GPIO1->FIOPIN & ARM_UPPER_PROX2)) )
				{
					break;
					
				}			
			}
			if(delay_time>40000000)	  //check the time
			{	
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay_ms(100);

				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );
				delay_ms(100);			 
				
				return 1;
			}
		}


		//NOZEL MOTOR ON RVS
		port_value |= 0X08;
		port_value ^= 0X20;
	
		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );	
		delay_ms(100);

		delay_time=0;
		
   		while(1)
		{
			delay_time++;
			
			if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX3)) )
			{
				delay_ms(100);
				if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX3)) )
				{
					break;
					
				}			
			}
			if(delay_time>40000000)	  //check the time
			{	
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay_ms(100);

				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay_ms(100);		 
				
				return 1;
			}
		}

//		port_value ^= 0X20;		
//
//		I2CWriteLength[PORT_USED] = 3;
//		I2CReadLength[PORT_USED] = 0;
//		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
//		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
//		I2CMasterBuffer[PORT_USED][2] = port_value;
//		I2CEngine( PORT_USED );	
//		
//		delay_ms(100);  
	
		flag1=0;
		flag2=0;
   		delay_time=0;

   		while(1)
		{
			delay_time++;
			if(delay_time>40000000)	  //check the time
			{			 
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );
				delay_ms(100);
						
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay_ms(100);	

				return 1;
			}
			if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX1)) && (flag1 == 0 ))
			{
				delay_ms(100);
				if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX1)) && (flag1 == 0 ))
				{
					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
					I2CMasterBuffer[PORT_USED][2] = 0x00;
					I2CEngine( PORT_USED );	
					delay_ms(100);	
					
					//ELECTROMAGNET OFF
					port_value ^=0X40;

					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
					I2CMasterBuffer[PORT_USED][2] = port_value;
					I2CEngine( PORT_USED );		
					flag1=1;
					delay_ms(100);
				}
	
			}
			if((!(LPC_GPIO3->FIOPIN & NOZEL_HOME)) && (flag2 == 0 ))
			{
				delay_ms(100);	
				if((!(LPC_GPIO3->FIOPIN & NOZEL_HOME)) && (flag2 == 0 ))
				{
				   	//NOZEL MOTOR OFF
					port_value ^= 0X08;
					//port_value ^= 0X10;
					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
					I2CMasterBuffer[PORT_USED][2] = port_value;
					I2CEngine( PORT_USED );		
					flag2=1;
					delay_ms(100);
				}
			}		
			if((flag1 == 1) && (flag2 == 1))
			{
				
				
				//delay_ms(500);
				break;
			}
		}

//		//PAINT SOLONOID OFF
		port_value ^= 0X10;			

		if(helmet1_flag == 1)
		{
		    port_value ^= 0X01;
		}
		else
		{
			
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x0A;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0X00;
			I2CEngine( PORT_USED );	
			delay_ms(100);
		}

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );		

		delay_ms(500);

		if((!(LPC_GPIO0->FIOPIN & INDEX_PROX1)))
		{
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0x14;
			I2CEngine( PORT_USED );

			delay_ms(4000);
			
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0x11;
			I2CEngine( PORT_USED );
			delay_ms(100);

			delay_time=0;
			while(1)
			{
				delay_time++;
				
				if((!(LPC_GPIO0->FIOPIN & INDEX_PROX2)) )
				{
					delay_ms(100);
					if((!(LPC_GPIO0->FIOPIN & INDEX_PROX2)) )
					{
						//delay_ms(2000);
						I2CWriteLength[PORT_USED] = 3;
						I2CReadLength[PORT_USED] = 0;
						I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
						I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
						I2CMasterBuffer[PORT_USED][2] = 0x00;
						I2CEngine( PORT_USED );
						delay_ms(100);
						delay_time=0;
						//delay_ms(10);	 					
						
						break;
					}					
				}
				else if(delay_time>80000000)	  //check the time
				{			 
					return 1;
				}
			}
		}
		else if((!(LPC_GPIO0->FIOPIN & INDEX_PROX2)))
		{
			
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0x24;
			I2CEngine( PORT_USED );

			delay_ms(4000);
			
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0x21;
			I2CEngine( PORT_USED );
			delay_ms(100);

			delay_time=0;
			while(1)
			{
				delay_time++;
				
				if((!(LPC_GPIO0->FIOPIN & INDEX_PROX1)) )
				{
					delay_ms(100);
					if((!(LPC_GPIO0->FIOPIN & INDEX_PROX1)) )
					{
						//delay_ms(2000);
						I2CWriteLength[PORT_USED] = 3;
						I2CReadLength[PORT_USED] = 0;
						I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
						I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
						I2CMasterBuffer[PORT_USED][2] = 0x00;
						I2CEngine( PORT_USED );	
						delay_ms(100);					
						//delay_ms(10);
						delay_time=0;						
									
						break;
					}
				}
				else if(delay_time>80000000)	  //check the time
				{			 
					return 1;
				}
			}	
		}
		
	port_value |= 0X40;
	port_value |= 0X20;

	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
	I2CMasterBuffer[PORT_USED][2] = port_value;
	I2CEngine( PORT_USED );
	delay_ms(100);		
	
	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x0A;		/* address */
	I2CMasterBuffer[PORT_USED][2] = 0X02;
	I2CEngine( PORT_USED );	
				 		
	delay_ms(100);

	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x0A;		/* address */
	I2CMasterBuffer[PORT_USED][2] = 0X00;
	I2CEngine( PORT_USED );
	delay_ms(100);	   


	return 0;

}

 unsigned int System_process8(void)
{
	unsigned int helmet1_flag;
	unsigned int delay_time;
	unsigned char port_value=0x00;
	
	
	helmet1_flag=0;

	
	if(System_status() == 1)
	{
		return 1;
	}

		//ELECTROMAGNET ON

	port_value |= 0x40;
	//port_value |= 0X20;

	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
	I2CMasterBuffer[PORT_USED][2] = port_value;
	I2CEngine( PORT_USED );	

	delay_ms(250);

		if((!(LPC_GPIO0->FIOPIN & INDEX_PROX2)))
		{
			//HELMET1 ON
			//port_value|= 0x02;
			port_value|= 0x01;
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
			I2CMasterBuffer[PORT_USED][2] = port_value;
			I2CEngine( PORT_USED );	
			delay_ms(100);

			helmet1_flag=1;
		}								  
		else if((!(LPC_GPIO0->FIOPIN & INDEX_PROX1)))
		{
			//HELMET2 ON

			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x0A;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0X04;
			I2CEngine( PORT_USED );	
			delay_ms(100);


		}

		 //SAVE THE nozel position
		I2CWriteLength[PORT_USED] = 4;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = 0XA0;
		I2CMasterBuffer[PORT_USED][1] = 0x00;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x01;		/* address */
		I2CMasterBuffer[PORT_USED][3] = 0x01;		/* Data0 */
	
			
		I2CEngine( PORT_USED );
		delay_ms(250);

		delay_ms(1000);
		port_value|= 0x20;

		port_value |= 0X08;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );		
	
		delay_ms(3000);	 //ANGLE CHANGED 1500
		
		
		//ON THE PAINT 
		port_value ^= 0X08;
		port_value |= 0x10;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value; 
		I2CEngine( PORT_USED );	
		delay_ms(5000);	

		port_value |= 0X04;
		port_value ^= 0X20;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );		
	
		delay_ms(1000);	 //ANGLE CHANGED 1500
 
		port_value ^= 0X04;	

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value; 
		I2CEngine( PORT_USED );	
		
		delay_ms(4000);	


		port_value |= 0X04;
		
		port_value ^= 0x10;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );		
	
		delay_ms(1000);	
		
   		delay_time=0;

   		while(1)
		{
			delay_time++;
			if(delay_time>40000000)	  //check the time
			{			 
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );
				delay_ms(100);
						
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay_ms(100);	

				return 1;
			}	 			
			else if((!(LPC_GPIO3->FIOPIN & NOZEL_HOME)) )
			{
				delay_ms(100);	
				if((!(LPC_GPIO3->FIOPIN & NOZEL_HOME)) )
				{
				   	//NOZEL MOTOR OFF
					port_value ^= 0X04;
					
					port_value ^= 0X40;
					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
					I2CMasterBuffer[PORT_USED][2] = port_value;
					
					I2CEngine( PORT_USED );							
					delay_ms(500);
					break;
				}
			}				
		}

		//SAVE THE nozel position
		I2CWriteLength[PORT_USED] = 4;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = 0XA0;
		I2CMasterBuffer[PORT_USED][1] = 0x00;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x01;		/* address */
		I2CMasterBuffer[PORT_USED][3] = 0x00;		/* Data0 */
	
			
		I2CEngine( PORT_USED );
		delay_ms(250);


		if(helmet1_flag == 1)
		{
		    port_value ^= 0X01;
		}
		else
		{
			
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x0A;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0X00;
			I2CEngine( PORT_USED );	
		}

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );		


		delay_ms(200);

		if((!(LPC_GPIO0->FIOPIN & INDEX_PROX1)))
		{
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0x14;
			I2CEngine( PORT_USED );

			delay_ms(4000);
			
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0x11;
			I2CEngine( PORT_USED );
			delay_time=0;
			while(1)
			{
				delay_time++;
				
				if((!(LPC_GPIO0->FIOPIN & INDEX_PROX2)) )
				{
					delay_ms(100);
					if((!(LPC_GPIO0->FIOPIN & INDEX_PROX2)) )
					{
						//delay_ms(2000);
						I2CWriteLength[PORT_USED] = 3;
						I2CReadLength[PORT_USED] = 0;
						I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
						I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
						I2CMasterBuffer[PORT_USED][2] = 0x00;
						I2CEngine( PORT_USED );
						delay_time=0;
						//delay_ms(10);	 					
						
						break;
					}					
				}
				else if(delay_time>80000000)	  //check the time
				{			 
					return 1;
				}
			}
		}
		else if((!(LPC_GPIO0->FIOPIN & INDEX_PROX2)))
		{
			
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0x24;
			I2CEngine( PORT_USED );

			delay_ms(4000);
			
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0x21;
			I2CEngine( PORT_USED );

			delay_time=0;
			while(1)
			{
				delay_time++;
				
				if((!(LPC_GPIO0->FIOPIN & INDEX_PROX1)) )
				{
					delay_ms(100);
					if((!(LPC_GPIO0->FIOPIN & INDEX_PROX1)) )
					{
						//delay_ms(2000);
						I2CWriteLength[PORT_USED] = 3;
						I2CReadLength[PORT_USED] = 0;
						I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
						I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
						I2CMasterBuffer[PORT_USED][2] = 0x00;
						I2CEngine( PORT_USED );						
						//delay_ms(10);
						delay_time=0;						
									
						break;
					}
				}
				else if(delay_time>80000000)	  //check the time
				{			 
					return 1;
				}
			}	
		}
		
	port_value |= 0X40;
	//port_value |= 0X20;

	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
	I2CMasterBuffer[PORT_USED][2] = port_value;
	I2CEngine( PORT_USED );		
	
	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x0A;		/* address */
	I2CMasterBuffer[PORT_USED][2] = 0X02;
	I2CEngine( PORT_USED );	
				 		
	delay_ms(100);

	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x0A;		/* address */
	I2CMasterBuffer[PORT_USED][2] = 0X00;
	I2CEngine( PORT_USED );	   

	return 0;
}

 unsigned int System_RND(void)
{
	unsigned int flag1,flag2,helmet1_flag;
	unsigned int delay_time;
	unsigned char port_value=0x00;
	
	
	helmet1_flag=0;

	
	if(System_status() == 1)
	{
		return 1;
	}

	port_value |= 0x40;
	port_value |= 0X20;

	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
	I2CMasterBuffer[PORT_USED][2] = port_value;
	I2CEngine( PORT_USED );	

	delay_ms(250);

		if((!(LPC_GPIO0->FIOPIN & INDEX_PROX2)))
		{
			//HELMET1 ON
			//port_value|= 0x02;
			port_value|= 0x01;
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
			I2CMasterBuffer[PORT_USED][2] = port_value;
			I2CEngine( PORT_USED );	
			delay_ms(100);

			helmet1_flag=1;
		}								  
		else if((!(LPC_GPIO0->FIOPIN & INDEX_PROX1)))
		{
			//HELMET2 ON

			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x0A;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0X04;
			I2CEngine( PORT_USED );	
			delay_ms(100); 

		}

		//SAVE THE nozel position
		I2CWriteLength[PORT_USED] = 4;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = 0XA0;
		I2CMasterBuffer[PORT_USED][1] = 0x00;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x01;		/* address */
		I2CMasterBuffer[PORT_USED][3] = 0x01;		/* Data0 */

	   	port_value |= 0X08;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );		
	
		delay_ms(3000);	 //ANGLE CHANGED 3500
		
		
		//ON THE PAINT 
		port_value ^= 0X08;
		port_value |= 0x10;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value; 
		I2CEngine( PORT_USED );	
		
		delay_ms(2000);	

		port_value |= 0X08;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );	
		delay_ms(2000);

		//ON THE PAINT 
		port_value ^= 0X08;
	//	port_value |= 0x10;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value; 
		I2CEngine( PORT_USED );	
		
		delay_ms(2000);	

		port_value |= 0X04;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );	
		delay_ms(1800);

		port_value ^= 0X04;
	//	port_value |= 0x10;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value; 
		I2CEngine( PORT_USED );	
		
		delay_ms(2000);	

		
		port_value |= 0X08;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );		
	
		delay_ms(1900);	 //ANGLE CHANGED 3500
		
		
		//ON THE PAINT 
		port_value ^= 0X08;
	//	port_value |= 0x10;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value; 
		I2CEngine( PORT_USED );	
		
		delay_ms(2000);	

		
		port_value |= 0X04;
		port_value ^= 0X20;
		port_value ^= 0X10;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );		
	
		delay_ms(2000);	
		

   		delay_time=0;

   		while(1)
		{
			delay_time++;
			if(delay_time > 40000000)	  //check the time
			{			 
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );
				delay_ms(100);
						
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );		
				delay_ms(100);

				return 1;
			}	 			
			else if((!(LPC_GPIO3->FIOPIN & NOZEL_HOME)) )
			{
				delay_ms(100);	
				if((!(LPC_GPIO3->FIOPIN & NOZEL_HOME)) )
				{
				   	//NOZEL MOTOR OFF
					port_value ^= 0X04;
					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
					I2CMasterBuffer[PORT_USED][2] = port_value;
					I2CEngine( PORT_USED );							
					delay_ms(500);
					break;
				}
			}				
		}

	   	//SAVE THE nozel position
		I2CWriteLength[PORT_USED] = 4;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = 0XA0;
		I2CMasterBuffer[PORT_USED][1] = 0x00;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x01;		/* address */
		I2CMasterBuffer[PORT_USED][3] = 0x00;		/* Data0 */
	
		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x48;
		I2CEngine( PORT_USED );
		delay_ms(1000);
				
		//NOZEL MOTOR ON
		port_value |= 0x04;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );	
		delay_ms(100);
		//delay_ms(500);

	

		port_value |= 0x10;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );	
		delay_ms(100);	

	   delay_time=0;
	   flag1=0;
		flag2=0;

   		while(1)
		{
			delay_time++;
			
			if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX3))  )
			{
				delay_ms(100);
				if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX3)))
				{
					
					break;
				}			
			}			
			else if(delay_time>50000000)	  
			{	
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay_ms(100);

				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );
				delay_ms(100);			 
				
				return 1;
			}
		}

			
		//NOZEL MOTOR OFF
		port_value ^= 0x04;
		port_value |= 0x20;
		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );	
		delay_ms(100);

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x42;
		I2CEngine( PORT_USED );
			delay_ms(100);	
				
	   delay_time=0;
	   
   		while(1)
		{
			delay_time++;
			
			if((!(LPC_GPIO1->FIOPIN & ARM_UPPER_PROX2))  )
			{
				delay_ms(100);
				if((!(LPC_GPIO1->FIOPIN & ARM_UPPER_PROX2)))
				{
					
					break;
				}			
			}			
			else if(delay_time>80000000)	  
			{	
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );
					delay_ms(100);	

				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
					delay_ms(100);		 
				
				return 1;
			}
		} 			

//		//NOZEL MOTOR ON
//		port_value |= 0X04;
//		I2CWriteLength[PORT_USED] = 3;
//		I2CReadLength[PORT_USED] = 0;
//		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
//		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
//		I2CMasterBuffer[PORT_USED][2] = port_value;
//		I2CEngine( PORT_USED );
//			delay_ms(100);	

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x48;
		I2CEngine( PORT_USED );	
			delay_ms(100);


		//delay_ms(3000);	

		//ARM CYLINDER ON		
//		port_value |= 0X20;
//		I2CWriteLength[PORT_USED] = 3;
//		I2CReadLength[PORT_USED] = 0;
//		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
//		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
//		I2CMasterBuffer[PORT_USED][2] = port_value;
//		I2CEngine( PORT_USED );	
//			delay_ms(100);
		delay_time=0;
		flag1=0;
		flag2=0;
		

   		while(1)
		{
			delay_time++;
			
			if((!(LPC_GPIO0->FIOPIN & ARM_UPPER_PROX1)) && (flag1 == 0) )
			{
				delay_ms(100);
				if((!(LPC_GPIO0->FIOPIN & ARM_UPPER_PROX1)) && (flag1 == 0) )
				{
					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
					I2CMasterBuffer[PORT_USED][2] = 0x00;
					I2CEngine( PORT_USED );
					delay_ms(1000); 		
					flag1=1;  
					break ;
					
				}			
			}
//			if((!(LPC_GPIO1->FIOPIN & NOZEL_INDEX)) && (flag2 == 0 ))
//			{
//				delay_ms(100);
//				if((!(LPC_GPIO1->FIOPIN & NOZEL_INDEX)) && (flag2 == 0 ))
//				{
//					port_value ^= 0x04;
//
//					I2CWriteLength[PORT_USED] = 3;
//					I2CReadLength[PORT_USED] = 0;
//					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
//					I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
//					I2CMasterBuffer[PORT_USED][2] = port_value;
//					I2CEngine( PORT_USED );		
//					flag2=1;
//					delay_ms(100);
//				}				
//			}
//			if((flag1 == 1) && (flag2 == 1))
//			{
//			   	
//				delay_ms(1500);	   //10000
//				//LPC_GPIO2->FIOCLR 	 = 	SOLONID_SIGNAL;
//				break;
//			}
			if(delay_time>40000000)	  //check the time
			{	
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay_ms(100);

				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );
				delay_ms(100);			 
				
				return 1;
			}
		}

		port_value |= 0X04;
		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );	
			delay_ms(100);
		delay_time=0;
		flag1=0;
		flag2=0;
		

   		while(1)
		{
			delay_time++;
			
			if((!(LPC_GPIO1->FIOPIN & NOZEL_INDEX)) && (flag2 == 0 ))
			{
				delay_ms(100);
				if((!(LPC_GPIO1->FIOPIN & NOZEL_INDEX)) && (flag2 == 0 ))
				{
					port_value ^= 0x04;

					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
					I2CMasterBuffer[PORT_USED][2] = port_value;
					I2CEngine( PORT_USED );
					delay_ms(100);		
					flag2=1;
					break;
					
				}				
			}
			if(delay_time>40000000)	  //check the time
			{	
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay_ms(100);

				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );
				delay_ms(100);			 
				
				return 1;
			}
		}

		port_value ^= 0X20;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );		
		delay_ms(100);


		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x88;
		I2CEngine( PORT_USED );	
		delay_ms(100);	

	   
		//NOZEL MOTOR ON RVS
		port_value |= 0X08;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );		
			delay_ms(100);	

		delay_time=0;

   		while(1)
		{
			delay_time++;
			
			if((!(LPC_GPIO1->FIOPIN & ARM_UPPER_PROX2))  )
			{
				delay_ms(100);
				if((!(LPC_GPIO1->FIOPIN & ARM_UPPER_PROX2)))
				{
					
					break;
				}			
			}			
			else if(delay_time>40000000)	  
			{	
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );
					delay_ms(100);	

				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
					delay_ms(100);		 
				
				return 1;
			}
		}


		//NOZEL MOTOR OFF RVS
		port_value ^= 0X08;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );		
	
		delay_ms(100);

		delay_time=0;

   		while(1)
		{
			delay_time++;
			
			if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX3))  )
			{
				delay_ms(100);
				if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX3)))
				{
					
					break;
				}			
			}				
			else if(delay_time>30000000)	  
			{	
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay_ms(100);

				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay_ms(100);		 
				
				return 1;
			}
		}


		//NOZEL MOTOR ON RVS
		port_value |= 0X08;
	//	port_value ^= 0X10;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );	

		delay_ms(100);

			delay_time=0;

   		while(1)
		{
			delay_time++;
			
			if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX2))  )
			{
				delay_ms(100);
				if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX2)))
				{
					
					break;
				}			
			}				
			else if(delay_time>30000000)	  
			{	
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay_ms(100);

				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );			 
				delay_ms(100);
				
				return 1;
			}
		}

		port_value ^= 0X10;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );	

		delay_ms(100);

	
		flag1=0;
		flag2=0;
   		delay_time=0;

   		while(1)
		{
			delay_time++;
			if(delay_time>40000000)	  //check the time
			{			 
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );
					delay_ms(100);
						
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
					delay_ms(100);	

				return 1;
			}
			if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX1)) && (flag1 == 0 ))
			{
				delay_ms(100);
				if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX1)) && (flag1 == 0 ))
				{
					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
					I2CMasterBuffer[PORT_USED][2] = 0x00;
					I2CEngine( PORT_USED );
						delay_ms(100);		
					
					//ELECTROMAGNET OFF
					port_value ^=0X40;

					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
					I2CMasterBuffer[PORT_USED][2] = port_value;
					I2CEngine( PORT_USED );		
					flag1=1;
					delay_ms(100);
				}
	
			}
			if((!(LPC_GPIO3->FIOPIN & NOZEL_HOME)) && (flag2 == 0 ))
			{
				delay_ms(100);	
				if((!(LPC_GPIO3->FIOPIN & NOZEL_HOME)) && (flag2 == 0 ))
				{
				   	//NOZEL MOTOR OFF
					port_value ^= 0X08;
					//port_value ^= 0X10;
					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
					I2CMasterBuffer[PORT_USED][2] = port_value;
					I2CEngine( PORT_USED );		
					flag2=1;
					delay_ms(100);
				}
			}		
			if((flag1 == 1) && (flag2 == 1))
			{
				
				
				//delay_ms(500);
				break;
			}
		}

		if(helmet1_flag == 1)
		{
		    port_value ^= 0X01;
		}
		else
		{
			
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x0A;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0X00;
			I2CEngine( PORT_USED );	
				delay_ms(100);
		}

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );		

		delay_ms(500);

		if((!(LPC_GPIO0->FIOPIN & INDEX_PROX1)))
		{
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0x14;
			I2CEngine( PORT_USED );

			delay_ms(4000);
			
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0x11;
			I2CEngine( PORT_USED );
			delay_ms(100);

			delay_time=0;
			while(1)
			{
				delay_time++;
				
				if((!(LPC_GPIO0->FIOPIN & INDEX_PROX2)) )
				{
					delay_ms(100);
					if((!(LPC_GPIO0->FIOPIN & INDEX_PROX2)) )
					{
						//delay_ms(2000);
						I2CWriteLength[PORT_USED] = 3;
						I2CReadLength[PORT_USED] = 0;
						I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
						I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
						I2CMasterBuffer[PORT_USED][2] = 0x00;
						I2CEngine( PORT_USED );
						delay_ms(100);
						delay_time=0;
						//delay_ms(10);	 					
						
						break;
					}					
				}
				else if(delay_time>80000000)	  //check the time
				{			 
					return 1;
				}
			}
		}
		else if((!(LPC_GPIO0->FIOPIN & INDEX_PROX2)))
		{
			
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0x24;
			I2CEngine( PORT_USED );

			delay_ms(4000);
			
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0x21;
			I2CEngine( PORT_USED );
			delay_ms(100);

			delay_time=0;
			while(1)
			{
				delay_time++;
				
				if((!(LPC_GPIO0->FIOPIN & INDEX_PROX1)) )
				{
					delay_ms(100);
					if((!(LPC_GPIO0->FIOPIN & INDEX_PROX1)) )
					{
						//delay_ms(2000);
						I2CWriteLength[PORT_USED] = 3;
						I2CReadLength[PORT_USED] = 0;
						I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
						I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
						I2CMasterBuffer[PORT_USED][2] = 0x00;
						I2CEngine( PORT_USED );
						delay_ms(100);						
						//delay_ms(10);
						delay_time=0;						
									
						break;
					}
				}
				else if(delay_time>80000000)	  //check the time
				{			 
					return 1;
				}
			}	
		}
		
	port_value |= 0X40;
	port_value |= 0X20;

	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
	I2CMasterBuffer[PORT_USED][2] = port_value;
	I2CEngine( PORT_USED );	
	delay_ms(100);	
	
	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x0A;		/* address */
	I2CMasterBuffer[PORT_USED][2] = 0X02;
	I2CEngine( PORT_USED );	
				 		
	delay_ms(100);

	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x0A;		/* address */
	I2CMasterBuffer[PORT_USED][2] = 0X00;
	I2CEngine( PORT_USED );	  
	delay_ms(100); 


	return 0;

}


unsigned int KIDS_OPEN(void) //kids_open_face
{
	unsigned int flag1,flag2,helmet1_flag;
	unsigned int delay_time;
	unsigned char port_value=0x00;
	
	
	helmet1_flag=0;

	
	if(System_status() == 1)
	{
		return 1;
	}

	port_value |= 0x40;
	port_value |= 0X20;

	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
	I2CMasterBuffer[PORT_USED][2] = port_value;
	I2CEngine( PORT_USED );	

	delay_ms(250);

		if((!(LPC_GPIO0->FIOPIN & INDEX_PROX2)))
		{
			//HELMET1 ON
			//port_value|= 0x02;
			port_value|= 0x01;
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
			I2CMasterBuffer[PORT_USED][2] = port_value;
			I2CEngine( PORT_USED );	
			delay_ms(100);

			helmet1_flag=1;
		}								  
		else if((!(LPC_GPIO0->FIOPIN & INDEX_PROX1)))
		{
			//HELMET2 ON

			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x0A;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0X04;
			I2CEngine( PORT_USED );	 
			delay_ms(100);

		}

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x48;
		I2CEngine( PORT_USED );	
		delay_ms(500);

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x00;
		I2CEngine( PORT_USED );	
		delay_ms(100);

		//SAVE THE nozel position
		I2CWriteLength[PORT_USED] = 4;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = 0XA0;
		I2CMasterBuffer[PORT_USED][1] = 0x00;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x01;		/* address */
		I2CMasterBuffer[PORT_USED][3] = 0x01;		/* Data0 */
	
			
		I2CEngine( PORT_USED );
		delay_ms(250);

	   	port_value |= 0X08;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );		
	
		delay_ms(3500);	 //ANGLE CHANGED 1500
		
		
		//ON THE PAINT 
		port_value ^= 0X08;
		port_value |= 0x10;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value; 
		I2CEngine( PORT_USED );	
		
		delay_ms(5000);	

//		//OFF THE PAINT 
//		port_value ^= 0x10;
//
//		I2CWriteLength[PORT_USED] = 3;
//		I2CReadLength[PORT_USED] = 0;
//		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
//		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
//		I2CMasterBuffer[PORT_USED][2] = port_value; 
//		I2CEngine( PORT_USED );	
//		delay_ms(1000);


		port_value |= 0X04;
		port_value ^= 0X20;
		port_value ^= 0x10;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );		
	
		delay_ms(2500);	
		
   		delay_time=0;

   		while(1)
		{
			delay_time++;
			if(delay_time>40000000)	  //check the time
			{			 
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );
				delay_ms(100);
						
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );
				delay_ms(100);		

				return 1;
			}	 			
			else if((!(LPC_GPIO3->FIOPIN & NOZEL_HOME)) )
			{
				delay_ms(100);	
				if((!(LPC_GPIO3->FIOPIN & NOZEL_HOME)) )
				{
				   	//NOZEL MOTOR OFF
					port_value ^= 0X04;
					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
					I2CMasterBuffer[PORT_USED][2] = port_value;
					I2CEngine( PORT_USED );							
					delay_ms(500);
					break;
				}
			}				
		}

	   	
		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x48;
		I2CEngine( PORT_USED );	
		delay_ms(100);		  		

		flag1=0;
		flag2=0;
							  	
		 //SAVE THE nozel position
		I2CWriteLength[PORT_USED] = 4;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = 0XA0;
		I2CMasterBuffer[PORT_USED][1] = 0x00;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x01;		/* address */
		I2CMasterBuffer[PORT_USED][3] = 0x00;		/* Data0 */		
			
		I2CEngine( PORT_USED );
		delay_ms(250); 	

		//NOZEL MOTOR ON
		port_value |= 0x04;
		//port_value |= 0x10;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );	

		delay_ms(100);		 		
			
		delay_time=0;

   		while(1)
		{
			delay_time++;
			
			if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX2))  )
			{
				delay_ms(100);
				if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX2)))
				{
					port_value ^= 0x04;
					port_value |= 0x10;
					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
					I2CMasterBuffer[PORT_USED][2] = port_value;
					I2CEngine( PORT_USED );						
					delay_ms(100); 	
					break;
				}			
			}			
			else if(delay_time > 30000000)	  
			{	
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay(100);

				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay(100);		 
				
				return 1;
			}
		}

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x42;
		I2CEngine( PORT_USED );	
		delay_ms(100);
	

		delay_time=0;

   		while(1)
		{
			delay_time++;
			if(delay_time > 120000000)	  //check the time
			{			 
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );
				delay_ms(100);
						
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );		
				delay_ms(100);

				return 1;
			}	 			
			else if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX3)) )
			{
				delay_ms(100);	
				if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX3)) )
				{
				   
					break;
				}
			}				
		}

//		//NOZEL MOTOR ON
		port_value |= 0X04;
		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );	
		delay_ms(100);


		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x48;
		I2CEngine( PORT_USED );	
		delay_ms(100);


		delay_time=0;
		flag1=0;
		flag2=0;

   		while(1)
		{
			delay_time++;
			
			if((!(LPC_GPIO1->FIOPIN & ARM_UPPER_PROX2)) && (flag1 == 0) )
			{
				delay_ms(100);
				if((!(LPC_GPIO1->FIOPIN & ARM_UPPER_PROX2)) && (flag1 == 0) )
				{
					flag1=1;
					break;
				//	delay_ms(100); 	
				}			
			}
			if((!(LPC_GPIO1->FIOPIN & NOZEL_INDEX)) && (flag1 == 0 ))
			{
				delay_ms(100);
				if((!(LPC_GPIO1->FIOPIN & NOZEL_INDEX)) && (flag1 == 0 ))
				{
					port_value ^= 0x04;

					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
					I2CMasterBuffer[PORT_USED][2] = port_value;
					I2CEngine( PORT_USED );	
					delay_ms(100);	
					flag2=1;
					
				}				
			}			
			if(delay_time>30000000)	  
			{	
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay_ms(100);

				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay_ms(100);		 
				
				return 1;
			}
		}

		//ARM CYLINDER ON		
		port_value |= 0X20;
		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );	
	    delay_ms(100);

		delay_time=0;
		flag1=0;
   		while(1)
		{
			delay_time++;
			
			if((!(LPC_GPIO0->FIOPIN & ARM_UPPER_PROX1)) && (flag1 == 0) )
			{
				delay_ms(100);
				if((!(LPC_GPIO0->FIOPIN & ARM_UPPER_PROX1)) && (flag1 == 0) )
				{
					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
					I2CMasterBuffer[PORT_USED][2] = 0x00;
					I2CEngine( PORT_USED );	
					delay_ms(100);
					flag1=1;						
				}			
			}
			if((!(LPC_GPIO1->FIOPIN & NOZEL_INDEX)) && (flag2 == 0 ))
			{
				delay_ms(100);
				if((!(LPC_GPIO1->FIOPIN & NOZEL_INDEX)) && (flag2 == 0 ))
				{
					port_value ^= 0x04;

					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
					I2CMasterBuffer[PORT_USED][2] = port_value;
					I2CEngine( PORT_USED );	
					delay_ms(100);	
					flag2=1;					
				}				
			}
			if((flag1 == 1) && (flag2 == 1))
			{
			   	
				delay_ms(500);	   //10000
				//LPC_GPIO2->FIOCLR 	 = 	SOLONID_SIGNAL;
				break;
			}
			if(delay_time>40000000)	  //check the time
			{	
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay_ms(100);

				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay_ms(100);		 
				
				return 1;
			}
		}		

		port_value ^= 0X20;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );		
		delay_ms(100);


		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
		I2CMasterBuffer[PORT_USED][2] = 0x88;
		I2CEngine( PORT_USED );		

	   
		delay_ms(100);  

		//NOZEL MOTOR ON RVS
		port_value |= 0X08;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );		
		delay_ms(100);

		delay_time=0;

   		while(1)
		{
			delay_time++;
			if(delay_time > 20000000)	  //check the time
			{			 
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );
				delay_ms(100);
						
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );		
				delay_ms(100);

				return 1;
			}	 			
			else if((!(LPC_GPIO1->FIOPIN & ARM_UPPER_PROX2)) )
			{
				delay_ms(100);	
				if((!(LPC_GPIO1->FIOPIN & ARM_UPPER_PROX2)) )
				{
				   
					break;
				}
			}				
		}

		delay_ms(3000);

		port_value ^= 0X08;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );	
		delay_ms(100);		
		
	
		delay_time=0;

   		while(1)
		{
			delay_time++;
			if(delay_time>120000000)	  //check the time
			{			 
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );
				delay_ms(100);
						
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );		
				delay_ms(100);

				return 1;
			}	 			
			else if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX3)) )
			{
				delay_ms(100);	
				if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX3)) )
				{
				   
					break;
				}
			}				
		}

		//NOZEL MOTOR ON RVS
		port_value |= 0X08;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );	

		delay_ms(100);
		delay_time=0;
		flag2=0;

   		while(1)
		{
			delay_time++;
			if(delay_time>120000000)	  //check the time
			{			 
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );
				delay_ms(100);
						
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );		
				delay_ms(100);

				return 1;
			}
			if((!(LPC_GPIO3->FIOPIN & NOZEL_HOME)) && (flag2 == 0 ))
			{
				delay_ms(100);	
				if((!(LPC_GPIO3->FIOPIN & NOZEL_HOME)) && (flag2 == 0 ))
				{
				   	//NOZEL MOTOR OFF
					port_value ^= 0X08;					
					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
					I2CMasterBuffer[PORT_USED][2] = port_value;
					I2CEngine( PORT_USED );		
					flag2=1;
					delay_ms(100);
				}
			}			 			
			if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX2)) )
			{
				delay_ms(100);	
				if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX2)) )
				{
				   
					break;
				}
			}				
		}

	  	port_value ^= 0X10;

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );		

		delay_ms(100);
		  	
		flag1=0;
		//flag2=0;
   		delay_time=0;

   		while(1)
		{
			delay_time++;
			if(delay_time>40000000)	  //check the time
			{			 
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );
				delay_ms(100);
						
				I2CWriteLength[PORT_USED] = 3;
				I2CReadLength[PORT_USED] = 0;
				I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
				I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
				I2CMasterBuffer[PORT_USED][2] = 0x00;
				I2CEngine( PORT_USED );	
				delay_ms(100);	

				return 1;
			}
			if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX1)) && (flag1 == 0 ))
			{
				delay_ms(100);
				if((!(LPC_GPIO0->FIOPIN & ARM_LOWER_PROX1)) && (flag1 == 0 ))
				{
					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
					I2CMasterBuffer[PORT_USED][2] = 0x00;
					I2CEngine( PORT_USED );		
					delay_ms(100);
					//ELECTROMAGNET OFF
					port_value ^=0X40;

					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
					I2CMasterBuffer[PORT_USED][2] = port_value;
					I2CEngine( PORT_USED );		
					flag1=1;
					delay_ms(100);
				}
	
			}
			if((!(LPC_GPIO3->FIOPIN & NOZEL_HOME)) && (flag2 == 0 ))
			{
				delay_ms(100);	
				if((!(LPC_GPIO3->FIOPIN & NOZEL_HOME)) && (flag2 == 0 ))
				{
				   	//NOZEL MOTOR OFF
					port_value ^= 0X08;					
					I2CWriteLength[PORT_USED] = 3;
					I2CReadLength[PORT_USED] = 0;
					I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
					I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
					I2CMasterBuffer[PORT_USED][2] = port_value;
					I2CEngine( PORT_USED );		
					flag2=1;
					delay_ms(100);
				}
			}		
			if((flag1 == 1) && (flag2 == 1))
			{  				
				//delay_ms(500);
				break;
			}
		}

//		//PAINT SOLONOID OFF
	//	port_value ^= 0X10;	 		

		if(helmet1_flag == 1)
		{
		    port_value ^= 0X01;
		}
		else
		{
			
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x0A;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0X00;
			I2CEngine( PORT_USED );	
			delay_ms(100);
		}

		I2CWriteLength[PORT_USED] = 3;
		I2CReadLength[PORT_USED] = 0;
		I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
		I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
		I2CMasterBuffer[PORT_USED][2] = port_value;
		I2CEngine( PORT_USED );		

		delay_ms(500);

		if((!(LPC_GPIO0->FIOPIN & INDEX_PROX1)))
		{
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0x14;
			I2CEngine( PORT_USED );

			delay_ms(4000);
			
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0x11;
			I2CEngine( PORT_USED );
			delay_ms(100);

			delay_time=0;
			while(1)
			{
				delay_time++;
				
				if((!(LPC_GPIO0->FIOPIN & INDEX_PROX2)) )
				{
					delay_ms(100);
					if((!(LPC_GPIO0->FIOPIN & INDEX_PROX2)) )
					{
						//delay_ms(2000);
						I2CWriteLength[PORT_USED] = 3;
						I2CReadLength[PORT_USED] = 0;
						I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
						I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
						I2CMasterBuffer[PORT_USED][2] = 0x00;
						I2CEngine( PORT_USED );
						delay_ms(100);

						delay_time=0;
						//delay_ms(10);	 					
						
						break;
					}					
				}
				else if(delay_time>80000000)	  //check the time
				{			 
					return 1;
				}
			}
		}
		else if((!(LPC_GPIO0->FIOPIN & INDEX_PROX2)))
		{
			
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0x24;
			I2CEngine( PORT_USED );

			delay_ms(4000);
			
			I2CWriteLength[PORT_USED] = 3;
			I2CReadLength[PORT_USED] = 0;
			I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
			I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
			I2CMasterBuffer[PORT_USED][2] = 0x21;
			I2CEngine( PORT_USED );
			delay_ms(100);

			delay_time=0;
			while(1)
			{
				delay_time++;
				
				if((!(LPC_GPIO0->FIOPIN & INDEX_PROX1)) )
				{
					delay_ms(100);
					if((!(LPC_GPIO0->FIOPIN & INDEX_PROX1)) )
					{
						//delay_ms(2000);
						I2CWriteLength[PORT_USED] = 3;
						I2CReadLength[PORT_USED] = 0;
						I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
						I2CMasterBuffer[PORT_USED][1] = 0x08;		/* address */
						I2CMasterBuffer[PORT_USED][2] = 0x00;
						I2CEngine( PORT_USED );						
						delay_ms(100);
						
						delay_time=0;						
									
						break;
					}
				}
				else if(delay_time>80000000)	  //check the time
				{			 
					return 1;
				}
			}	
		}
		
	port_value |= 0X40;
	port_value |= 0X20;

	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x09;		/* address */
	I2CMasterBuffer[PORT_USED][2] = port_value;
	I2CEngine( PORT_USED );		
	delay_ms(100);
	
	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x0A;		/* address */
	I2CMasterBuffer[PORT_USED][2] = 0X02;
	I2CEngine( PORT_USED );	
				 		
	delay_ms(100);

	I2CWriteLength[PORT_USED] = 3;
	I2CReadLength[PORT_USED] = 0;
	I2CMasterBuffer[PORT_USED][0] = PCA95505_ADDR1;
	I2CMasterBuffer[PORT_USED][1] = 0x0A;		/* address */
	I2CMasterBuffer[PORT_USED][2] = 0X00;
	I2CEngine( PORT_USED );	   
	delay_ms(100);


	return 0;

}